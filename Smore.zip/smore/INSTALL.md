# Smore Installation Guide

## Prerequisites

Before installing Smore, ensure you have the following prerequisites:

- **Python 3.8+**: Required for running the application
- **CUDA Toolkit** (recommended for NVIDIA GPUs): For GPU acceleration
- **OpenCL Runtime** (for AMD/Intel GPUs): Alternative GPU acceleration
- **Docker** (optional): For containerized deployment

## Installation Methods

### Method 1: Standard Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/smore.git
   cd smore
   ```

2. **Create a virtual environment** (recommended):
   ```bash
   # Windows
   python -m venv venv
   venv\Scripts\activate

   # macOS/Linux
   python3 -m venv venv
   source venv/bin/activate
   ```

3. **Install required dependencies**:
   ```bash
   pip install -r smore/requirements.txt
   ```

4. **Run the application**:
   ```bash
   python run.py
   ```

### Method 2: Docker Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/smore.git
   cd smore
   ```

2. **Build and run using Docker Compose**:
   ```bash
   docker-compose up --build
   ```

   This will build the Docker image and start the container with GPU passthrough.

3. **For GPU support with Docker**:
   - Ensure you have the NVIDIA Container Toolkit installed for NVIDIA GPUs
   - Make sure Docker is configured for GPU passthrough

## GPU Setup

### NVIDIA GPUs

1. **Install CUDA Toolkit**:
   - Download and install from [NVIDIA's website](https://developer.nvidia.com/cuda-downloads)
   - Ensure your GPU drivers are up to date

2. **Verify CUDA installation**:
   ```bash
   nvidia-smi
   ```

### AMD GPUs

1. **Install OpenCL Runtime**:
   - Download and install from [AMD's website](https://www.amd.com/en/support)
   - Ensure your GPU drivers are up to date

2. **Verify OpenCL installation**:
   ```bash
   # Linux
   clinfo

   # Windows (via OpenCL application)
   ```

## Troubleshooting

### Common Issues

1. **GPU Not Detected**:
   - Ensure your GPU drivers are up to date
   - Verify CUDA/OpenCL is properly installed
   - Check that your GPU is compatible with CUDA/OpenCL

2. **Docker GPU Passthrough Issues**:
   - Ensure NVIDIA Container Toolkit is installed
   - Verify that Docker is configured for GPU access
   - Check the Docker Compose file has proper GPU configuration

3. **Performance Issues**:
   - Ensure no other GPU-intensive applications are running
   - Check GPU temperature and throttling
   - Verify you're using the latest drivers

### Getting Help

If you encounter issues not covered here, please:
- Check the GitHub repository's issues section
- Join our community Discord channel
- Contact us at support@example.com

## Updating

To update Smore to the latest version:

```bash
# Pull the latest changes
git pull

# Update dependencies
pip install -r smore/requirements.txt --upgrade

# Or for Docker
docker-compose down
docker-compose pull
docker-compose up --build
``` 