import os
import hashlib
import binascii
import base58
import ecdsa
from typing import Dict, Tuple
from datetime import datetime
import random
import requests
import time

class BitcoinWallet:
    def __init__(self):
        self.private_key = None
        self.private_key_hex = None
        self.wif = None
        self.public_key = None
        self.p2pkh_address = None
        self.p2wpkh_address = None
    
    def generate_random(self) -> Dict[str, str]:
        """Generate a random Bitcoin wallet (private key and derived addresses)"""
        # Generate a random private key (32 bytes)
        self.private_key = os.urandom(32)
        return self._process_private_key()
    
    def from_hex(self, private_key_hex: str) -> Dict[str, str]:
        """Generate wallet from a hexadecimal private key"""
        # Convert hex string to bytes
        self.private_key = bytes.fromhex(private_key_hex)
        return self._process_private_key()
    
    def from_integer(self, private_key_int: int) -> Dict[str, str]:
        """Generate wallet from an integer private key"""
        # Ensure the integer is within the valid range
        if private_key_int <= 0 or private_key_int >= 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141:
            raise ValueError("Private key outside allowed range")
            
        # Convert to 32-byte big-endian representation
        self.private_key = private_key_int.to_bytes(32, byteorder='big')
        return self._process_private_key()
    
    def _process_private_key(self) -> Dict[str, str]:
        """Process a private key to derive addresses and other formats"""
        # Convert private key to hex
        self.private_key_hex = self.private_key.hex()
        
        # Create WIF format
        self.wif = self._to_wif(self.private_key)
        
        # Get public key
        sk = ecdsa.SigningKey.from_string(self.private_key, curve=ecdsa.SECP256k1)
        vk = sk.get_verifying_key()
        self.public_key = ('04' + vk.to_string().hex())
        
        # Compressed public key (for P2WPKH)
        x_coord = vk.pubkey.point.x()
        y_coord = vk.pubkey.point.y()
        prefix = '02' if y_coord % 2 == 0 else '03'
        compressed_public_key = prefix + x_coord.to_bytes(32, byteorder='big').hex()
        
        # Generate P2PKH address (legacy)
        self.p2pkh_address = self._public_key_to_p2pkh(self.public_key)
        
        # Generate P2WPKH address (segwit)
        self.p2wpkh_address = self._public_key_to_p2wpkh(compressed_public_key)
        
        # Return all wallet data
        return {
            'private_key_hex': self.private_key_hex,
            'wif': self.wif,
            'public_key': self.public_key,
            'p2pkh_address': self.p2pkh_address,
            'p2wpkh_address': self.p2wpkh_address
        }
    
    def _to_wif(self, private_key: bytes) -> str:
        """Convert private key to Wallet Import Format (WIF)"""
        # Add version byte (0x80 for mainnet)
        extended_key = b'\x80' + private_key
        
        # Compute SHA-256 hash of extended key
        sha256_1 = hashlib.sha256(extended_key).digest()
        
        # Compute SHA-256 hash of first SHA-256 hash
        sha256_2 = hashlib.sha256(sha256_1).digest()
        
        # Take first 4 bytes of second SHA-256 hash (checksum)
        checksum = sha256_2[:4]
        
        # Add checksum to extended key
        wif_bytes = extended_key + checksum
        
        # Encode using Base58
        wif = base58.b58encode(wif_bytes).decode('utf-8')
        
        return wif
    
    def _public_key_to_p2pkh(self, public_key: str) -> str:
        """Convert public key to P2PKH address"""
        # Get the public key bytes
        public_key_bytes = bytes.fromhex(public_key)
        
        # SHA-256 hash
        sha256_hash = hashlib.sha256(public_key_bytes).digest()
        
        # RIPEMD-160 hash
        ripemd160 = hashlib.new('ripemd160')
        ripemd160.update(sha256_hash)
        ripemd160_hash = ripemd160.digest()
        
        # Add version byte (0x00 for mainnet)
        versioned_hash = b'\x00' + ripemd160_hash
        
        # Double SHA-256 for checksum
        checksum = hashlib.sha256(hashlib.sha256(versioned_hash).digest()).digest()[:4]
        
        # Combine versioned hash and checksum
        binary_address = versioned_hash + checksum
        
        # Encode with Base58
        p2pkh_address = base58.b58encode(binary_address).decode('utf-8')
        
        return p2pkh_address
    
    def _public_key_to_p2wpkh(self, compressed_public_key: str) -> str:
        """Convert public key to P2WPKH (Bech32) address"""
        # Get the compressed public key bytes
        public_key_bytes = bytes.fromhex(compressed_public_key)
        
        # SHA-256 hash
        sha256_hash = hashlib.sha256(public_key_bytes).digest()
        
        # RIPEMD-160 hash
        ripemd160 = hashlib.new('ripemd160')
        ripemd160.update(sha256_hash)
        hash160 = ripemd160.digest()
        
        # For simplicity, we'll return the traditional P2SH-wrapped P2WPKH format
        # since implementing full Bech32 encoding is complex
        # In a real implementation, you would use proper Bech32 encoding here
        redeem_script = b'\x00\x14' + hash160
        sha256_hash = hashlib.sha256(redeem_script).digest()
        ripemd160 = hashlib.new('ripemd160')
        ripemd160.update(sha256_hash)
        script_hash = ripemd160.digest()
        
        # Add version byte (0x05 for P2SH)
        versioned_hash = b'\x05' + script_hash
        
        # Double SHA-256 for checksum
        checksum = hashlib.sha256(hashlib.sha256(versioned_hash).digest()).digest()[:4]
        
        # Combine versioned hash and checksum
        binary_address = versioned_hash + checksum
        
        # Encode with Base58
        p2wpkh_address = base58.b58encode(binary_address).decode('utf-8')
        
        return p2wpkh_address
        
    def check_balance(self, address: str) -> Dict[str, float]:
        """
        Check the balance of a Bitcoin address using Blockstream API
        Returns a dictionary with balance information
        """
        # Use the static method implementation for consistency
        return BitcoinWallet.check_address_balance(address)
        
    @staticmethod
    def check_address_balance(address: str, timeout: float = 10.0) -> Dict[str, float]:
        """
        Static method to check the balance of a Bitcoin address using Blockstream API
        Returns a dictionary with balance information
        
        Args:
            address: The Bitcoin address to check
            timeout: Timeout in seconds for API requests
            
        Returns:
            Dictionary with balance information
        """
        try:
            # Real implementation using Blockstream API
            api_url = f"https://blockstream.info/api/address/{address}"
            
            # Add a small delay to avoid rate limiting but keep it minimal
            time.sleep(0.1)
            
            # Use timeout parameter for both requests to prevent hanging
            response = requests.get(api_url, timeout=timeout)
            
            if response.status_code == 200:
                data = response.json()
                
                # Extract balance in satoshis and convert to BTC
                balance_satoshis = data.get('chain_stats', {}).get('funded_txo_sum', 0) - \
                                  data.get('chain_stats', {}).get('spent_txo_sum', 0)
                
                balance_btc = balance_satoshis / 100000000  # Convert satoshis to BTC
                
                # Get current BTC price (in a real app, you'd use a price API)
                # Use a cached price value if the request was recent
                btc_price = BitcoinWallet._get_cached_btc_price(timeout)
                
                return {
                    'balance_btc': balance_btc,
                    'balance_usd': balance_btc * btc_price,
                    'last_updated': datetime.now().isoformat(),
                    'tx_count': data.get('chain_stats', {}).get('tx_count', 0)
                }
            
            return {
                'balance_btc': 0.0,
                'balance_usd': 0.0,
                'last_updated': datetime.now().isoformat(),
                'tx_count': 0
            }
            
        except Exception as e:
            print(f"Error checking balance: {e}")
            # Return empty data on error, but don't fail
            return {
                'balance_btc': 0.0,
                'balance_usd': 0.0,
                'last_updated': datetime.now().isoformat(),
                'tx_count': 0,
                'error': str(e)
            }
    
    # Class variables for price caching
    _cached_btc_price = 60000  # Default fallback price
    _price_last_updated = 0    # Unix timestamp of last update
    _price_cache_duration = 60 # Cache duration in seconds
    
    @staticmethod
    def _get_cached_btc_price(timeout: float = 5.0) -> float:
        """
        Get BTC price, using a cached value if it's recent enough
        
        Args:
            timeout: Timeout for API request in seconds
            
        Returns:
            Current BTC price in USD
        """
        current_time = time.time()
        
        # If cache is valid, return cached price
        if current_time - BitcoinWallet._price_last_updated < BitcoinWallet._price_cache_duration:
            return BitcoinWallet._cached_btc_price
            
        # Otherwise fetch new price
        try:
            response = requests.get(
                "https://api.coindesk.com/v1/bpi/currentprice/USD.json", 
                timeout=timeout
            )
            
            if response.status_code == 200:
                price_data = response.json()
                BitcoinWallet._cached_btc_price = float(price_data['bpi']['USD']['rate'].replace(',', ''))
                BitcoinWallet._price_last_updated = current_time
        except Exception as e:
            print(f"Error fetching BTC price: {e}")
            # Keep using the existing cached price on error
            
        return BitcoinWallet._cached_btc_price 