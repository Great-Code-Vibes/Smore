import os
import json
import logging
import time
from datetime import datetime
from typing import Dict, Any, List, Optional
from pathlib import Path

class BruteForceLogger:
    def __init__(self, log_dir: Optional[str] = None):
        # Set up directories
        if log_dir is None:
            # Use default location
            base_dir = Path(__file__).parent.parent
            self.log_dir = base_dir / "logs"
        else:
            self.log_dir = Path(log_dir)
        
        # Create log directories if they don't exist
        self.log_dir.mkdir(exist_ok=True)
        
        # Set up file paths
        self.match_log_path = self.log_dir / "matches.log"
        self.performance_log_path = self.log_dir / "performance.log"
        self.progress_path = self.log_dir / "progress.json"
        
        # Configure logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger('smore.brute_force')
        
        # Set up file handlers
        self._setup_file_handlers()
        
        # Initialize match counter
        self.match_count = 0
        
        # Track metrics
        self.start_time = time.time()
        self.total_attempts = 0
        self.last_key = 0
        
    def _setup_file_handlers(self):
        # Match log file handler
        match_handler = logging.FileHandler(self.match_log_path)
        match_handler.setLevel(logging.INFO)
        match_formatter = logging.Formatter('%(asctime)s - %(message)s')
        match_handler.setFormatter(match_formatter)
        
        # Add handlers to logger
        self.logger.addHandler(match_handler)
    
    def log_match(self, wallet_data: Dict[str, str], balance_data: Optional[Dict[str, Any]] = None) -> None:
        """
        Log a match found with the given wallet data and optional balance data.
        
        Args:
            wallet_data: Dictionary with wallet details (private key, addresses, etc.)
            balance_data: Optional dictionary with balance information
        """
        self.match_count += 1
        
        # Format the log message
        log_msg = f"Match #{self.match_count}:\n"
        log_msg += f"Private Key (HEX): {wallet_data['private_key_hex']}\n"
        log_msg += f"Private Key (WIF): {wallet_data['wif']}\n"
        log_msg += f"Public Key: {wallet_data['public_key']}\n"
        log_msg += f"P2PKH Address: {wallet_data['p2pkh_address']}\n"
        log_msg += f"P2WPKH Address: {wallet_data['p2wpkh_address']}\n"
        
        if balance_data and 'balance_btc' in balance_data:
            log_msg += f"Balance: {balance_data['balance_btc']:.8f} BTC"
            if 'balance_usd' in balance_data:
                log_msg += f" (${balance_data['balance_usd']:.2f} USD)"
        
        # Log to file
        self.logger.info(log_msg)
        
        # Also log to console
        print(f"\n[MATCH FOUND] {wallet_data['p2pkh_address']}")
        
        # Save match to JSON file
        self._save_match_to_json(wallet_data, balance_data)
    
    def _save_match_to_json(self, wallet_data: Dict[str, str], balance_data: Optional[Dict[str, Any]]) -> None:
        """Save match details to a JSON file for later reference"""
        match_file = self.log_dir / f"match_{self.match_count}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        match_data = {
            "timestamp": datetime.now().isoformat(),
            "wallet_data": wallet_data,
            "balance_data": balance_data if balance_data else {}
        }
        
        with open(match_file, 'w') as f:
            json.dump(match_data, f, indent=2)
    
    def log_performance(self, 
                        current_key: int, 
                        attempts: int, 
                        elapsed_time: float,
                        keys_per_second: float) -> None:
        """
        Log performance metrics to a file.
        
        Args:
            current_key: Current key being processed
            attempts: Number of attempts in this batch
            elapsed_time: Time elapsed for this batch
            keys_per_second: Keys processed per second
        """
        # Update totals
        self.total_attempts += attempts
        self.last_key = current_key
        
        # Calculate overall stats
        total_elapsed = time.time() - self.start_time
        overall_rate = self.total_attempts / total_elapsed if total_elapsed > 0 else 0
        
        # Format the timestamp
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Create log entry
        log_entry = {
            "timestamp": timestamp,
            "current_key": current_key,
            "current_key_hex": hex(current_key),
            "batch_attempts": attempts,
            "batch_time": elapsed_time,
            "batch_rate": keys_per_second,
            "total_attempts": self.total_attempts,
            "total_time": total_elapsed,
            "overall_rate": overall_rate,
            "matches_found": self.match_count
        }
        
        # Write to performance log
        with open(self.performance_log_path, 'a') as f:
            f.write(json.dumps(log_entry) + "\n")
            
        # Return the performance data (for display)
        return log_entry
    
    def save_progress(self, current_key: int, total_attempts: int, attack_settings: Optional[Dict[str, Any]] = None) -> None:
        """
        Save current progress to a file for later resumption.
        
        Args:
            current_key: Current key being processed
            total_attempts: Total attempts made so far
            attack_settings: Dictionary containing attack mode configurations
        """
        # Update our internal state
        self.last_key = current_key
        self.total_attempts = total_attempts
        
        # Create progress data
        progress_data = {
            "timestamp": datetime.now().isoformat(),
            "current_key": current_key,
            "current_key_hex": hex(current_key),
            "total_attempts": total_attempts,
            "matches_found": self.match_count,
            "elapsed_time": time.time() - self.start_time
        }
        
        # Add attack settings if provided
        if attack_settings:
            progress_data["attack_settings"] = attack_settings
            
            # Store address format from attack settings
            if "address_format" in attack_settings:
                progress_data["address_format"] = attack_settings["address_format"]
                
            # Store minimum balance from attack settings
            if "min_balance" in attack_settings:
                progress_data["min_balance_threshold"] = attack_settings["min_balance"]
                
            # Store keys per second for display
            if "keys_per_second" in attack_settings:
                progress_data["keys_per_second"] = attack_settings["keys_per_second"]
        
        # Write to progress file
        with open(self.progress_path, 'w') as f:
            json.dump(progress_data, f, indent=2)
    
    def load_progress(self) -> Dict[str, Any]:
        """
        Load progress from a file.
        
        Returns:
            Dictionary with progress information or empty dict if no progress file
        """
        if not os.path.exists(self.progress_path):
            return {}
        
        try:
            with open(self.progress_path, 'r') as f:
                progress_data = json.load(f)
                
            # Update internal state
            if 'current_key' in progress_data:
                self.last_key = progress_data['current_key']
            if 'total_attempts' in progress_data:
                self.total_attempts = progress_data['total_attempts']
            if 'matches_found' in progress_data:
                self.match_count = progress_data['matches_found']
            if 'elapsed_time' in progress_data:
                # Adjust start time to account for previous elapsed time
                self.start_time = time.time() - progress_data['elapsed_time']
                
            return progress_data
            
        except (json.JSONDecodeError, KeyError) as e:
            self.logger.error(f"Error loading progress file: {e}")
            return {}
    
    def export_results(self, export_file: str) -> bool:
        """
        Export all match results to a specified file.
        
        Args:
            export_file: Path to the export file
            
        Returns:
            True if export successful, False otherwise
        """
        try:
            # Get all match files
            match_files = sorted(self.log_dir.glob("match_*.json"))
            
            if not match_files:
                self.logger.warning("No matches to export")
                return False
            
            # Compile all matches
            all_matches = []
            for match_file in match_files:
                with open(match_file, 'r') as f:
                    try:
                        match_data = json.load(f)
                        all_matches.append(match_data)
                    except json.JSONDecodeError:
                        self.logger.error(f"Error parsing match file {match_file}")
            
            # Generate export
            export_data = {
                "timestamp": datetime.now().isoformat(),
                "total_matches": len(all_matches),
                "matches": all_matches
            }
            
            # Save export
            with open(export_file, 'w') as f:
                json.dump(export_data, f, indent=2)
                
            self.logger.info(f"Exported {len(all_matches)} matches to {export_file}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error exporting results: {e}")
            return False 