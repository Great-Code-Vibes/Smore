"""
Smore: Bitcoin Wallet Brute-force Tool
Package initialization
"""

__version__ = "1.0.0"
__author__ = "Smore Team" 