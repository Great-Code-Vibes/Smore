"""
High-performance PyQt implementation of the Smore Bitcoin Wallet Brute-force Tool.
This implementation is optimized for performance and resource usage compared to customtkinter.
"""

import os
import sys
import time
import logging
import threading
from pathlib import Path
from typing import Dict, List, Set, Optional, Any, Tuple

# Configure logger
logger = logging.getLogger(__name__)

# Determine correct PyQt version to use
try:
    from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                                QHBoxLayout, QPushButton, QLabel, QTabWidget, 
                                QLineEdit, QTextEdit, QProgressBar, QMessageBox,
                                QFileDialog, QSplitter, QComboBox, QSpinBox,
                                QDoubleSpinBox, QRadioButton, QButtonGroup,
                                QFrame, QScrollArea, QSlider, QGridLayout,
                                QCheckBox)
    from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QSize
    from PyQt6.QtGui import QIcon, QFont, QPixmap
    PYQT_VERSION = 6
except ImportError:
    from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                                QHBoxLayout, QPushButton, QLabel, QTabWidget, 
                                QLineEdit, QTextEdit, QProgressBar, QMessageBox,
                                QFileDialog, QSplitter, QComboBox, QSpinBox,
                                QDoubleSpinBox, QRadioButton, QButtonGroup,
                                QFrame, QScrollArea, QSlider, QGridLayout,
                                QCheckBox)
    from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer, QSize
    from PyQt5.QtGui import QIcon, QFont, QPixmap
    PYQT_VERSION = 5

# Import Smore utilities
try:
    from smore.utils import BitcoinWallet, GPUAccelerator, BruteForceLogger
except ImportError:
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    from smore.utils import BitcoinWallet, GPUAccelerator, BruteForceLogger

class BruteForceThread(QThread):
    """Thread for running brute force operations without blocking the UI."""
    # Signals for thread communication
    status_update = pyqtSignal(str)
    progress_update = pyqtSignal(dict)
    match_found = pyqtSignal(dict)
    finished = pyqtSignal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.running = False
        self.stop_event = threading.Event()
        
        # Initialize accelerator
        self.gpu_accelerator = GPUAccelerator()
        
        # Setup logger
        base_dir = Path(__file__).parent.parent.parent
        logs_dir = base_dir / "smore" / "logs"
        self.logger = BruteForceLogger(log_dir=str(logs_dir))
    
    def run(self):
        """Main thread execution loop."""
        self.running = True
        self.stop_event.clear()
        
        # Placeholder update loop
        update_interval = 0.2  # seconds
        
        while self.running and not self.stop_event.is_set():
            # Emit progress update
            self.progress_update.emit({
                "current_key": self.gpu_accelerator.current_key,
                "current_address": self.gpu_accelerator.current_address,
                "keys_per_second": self.gpu_accelerator.keys_per_second,
                "matches_found": 0,  # placeholder
            })
            
            # Sleep to prevent high CPU usage
            time.sleep(update_interval)
        
        self.running = False
        self.finished.emit()
    
    def start_brute_force(self, settings):
        """Start brute force with the given settings."""
        if self.running:
            return False
            
        self.status_update.emit("Starting brute force attack...")
        
        # Extract settings
        start_key = settings.get("start_key", 1)
        target_addresses = settings.get("target_addresses", set())
        use_p2wpkh = settings.get("address_format", "P2PKH") == "P2WPKH"
        attack_settings = settings.get("attack_settings", {})
        
        # Start GPU acceleration
        self.gpu_accelerator.start_brute_force(
            start_key=start_key,
            target_addresses=target_addresses,
            use_p2wpkh=use_p2wpkh,
            callback=self._on_match_found,
            stop_event=self.stop_event,
            save_progress=self._save_progress,
            attack_settings=attack_settings
        )
        
        # Start the thread
        self.start()
        return True
    
    def stop_brute_force(self):
        """Stop the brute force operation."""
        if not self.running:
            return False
            
        self.status_update.emit("Stopping brute force attack...")
        self.stop_event.set()
        self.gpu_accelerator.stop_brute_force()
        self.running = False
        return True
    
    def _on_match_found(self, wallet_data):
        """Handle a match being found."""
        # Log the match
        self.logger.log_match(wallet_data, None)
        
        # Emit signal with match data
        self.match_found.emit(wallet_data)
    
    def _save_progress(self, current_key, keys_per_second):
        """Save current progress."""
        self.logger.save_progress(
            current_key=current_key,
            total_attempts=self.logger.total_attempts + int(keys_per_second * 2)
        )

class SmoreMainWindow(QMainWindow):
    """Main application window for Smore using PyQt."""
    
    def __init__(self):
        super().__init__()
        
        # Application state
        self.target_addresses = set()
        self.matches = []
        self.brute_force_thread = BruteForceThread(self)
        
        # Initialize UI
        self.init_ui()
        
        # Connect thread signals
        self.setup_thread_connections()
        
        # Initialize backend components
        self.init_backend()
    
    def init_ui(self):
        """Initialize the user interface."""
        # Set main window properties
        self.setWindowTitle("Smore: Bitcoin Wallet Brute-force Tool (PyQt)")
        self.setMinimumSize(1200, 800)
        
        # Create central widget and main layout
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        
        self.main_layout = QHBoxLayout(self.central_widget)
        
        # Create sidebar
        self.sidebar = QWidget()
        self.sidebar.setFixedWidth(300)
        self.sidebar_layout = QVBoxLayout(self.sidebar)
        self.main_layout.addWidget(self.sidebar)
        
        # Create main content area
        self.content_widget = QWidget()
        self.content_layout = QVBoxLayout(self.content_widget)
        self.main_layout.addWidget(self.content_widget)
        
        # Add sidebar components
        self.create_sidebar_ui()
        
        # Add content components
        self.create_content_ui()
        
        # Add status bar
        self.statusBar().showMessage("Ready")
    
    def create_sidebar_ui(self):
        """Create the sidebar UI components."""
        # Target addresses section
        self.address_frame = QFrame()
        self.address_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.address_layout = QVBoxLayout(self.address_frame)
        
        self.address_label = QLabel("📁 Target Addresses")
        self.address_label.setStyleSheet("font-weight: bold; font-size: 16px;")
        self.address_layout.addWidget(self.address_label)
        
        self.address_count_label = QLabel("0 addresses loaded")
        self.address_layout.addWidget(self.address_count_label)
        
        self.load_addresses_button = QPushButton("Load Address File")
        self.load_addresses_button.clicked.connect(self.load_target_addresses)
        self.address_layout.addWidget(self.load_addresses_button)
        
        self.address_layout.addWidget(QLabel("Or enter addresses manually (one per line):"))
        
        self.address_text = QTextEdit()
        self.address_text.setMinimumHeight(100)
        self.address_layout.addWidget(self.address_text)
        
        self.sidebar_layout.addWidget(self.address_frame)
        
        # Attack settings section
        self.attack_frame = QFrame()
        self.attack_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.attack_layout = QVBoxLayout(self.attack_frame)
        
        self.attack_label = QLabel("🎯 Attack Mode")
        self.attack_label.setStyleSheet("font-weight: bold; font-size: 16px;")
        self.attack_layout.addWidget(self.attack_label)
        
        # Attack mode options
        self.attack_mode_group = QButtonGroup(self)
        self.default_mode_radio = QRadioButton("Default (All Keys)")
        self.puzzle_mode_radio = QRadioButton("BTC Puzzle Challenge")
        self.pattern_mode_radio = QRadioButton("Pattern Search")
        self.range_mode_radio = QRadioButton("Range Splitting")
        
        self.default_mode_radio.setChecked(True)
        self.attack_mode_group.addButton(self.default_mode_radio)
        self.attack_mode_group.addButton(self.puzzle_mode_radio)
        self.attack_mode_group.addButton(self.pattern_mode_radio)
        self.attack_mode_group.addButton(self.range_mode_radio)
        
        self.attack_layout.addWidget(self.default_mode_radio)
        self.attack_layout.addWidget(self.puzzle_mode_radio)
        self.attack_layout.addWidget(self.pattern_mode_radio)
        self.attack_layout.addWidget(self.range_mode_radio)
        
        # Start key input
        self.attack_layout.addWidget(QLabel("Start Private Key (int):"))
        self.start_key_input = QLineEdit("1")
        self.attack_layout.addWidget(self.start_key_input)
        self.attack_layout.addWidget(QLabel("Valid range: 1 to 2^256 - 1"))
        
        # Create specialized settings frames for each attack mode
        # Puzzle Challenge options
        self.puzzle_frame = QFrame()
        self.puzzle_layout = QVBoxLayout(self.puzzle_frame)
        self.puzzle_layout.addWidget(QLabel("Puzzle Level (0-100):"))
        
        self.puzzle_level_slider = QSlider(Qt.Orientation.Horizontal if PYQT_VERSION == 6 else Qt.Horizontal)
        self.puzzle_level_slider.setMinimum(0)
        self.puzzle_level_slider.setMaximum(100)
        self.puzzle_level_slider.setValue(30)
        self.puzzle_level_label = QLabel("Level 30")
        
        puzzle_slider_layout = QHBoxLayout()
        puzzle_slider_layout.addWidget(self.puzzle_level_slider)
        puzzle_slider_layout.addWidget(self.puzzle_level_label)
        self.puzzle_layout.addLayout(puzzle_slider_layout)
        
        self.puzzle_level_slider.valueChanged.connect(
            lambda value: self.puzzle_level_label.setText(f"Level {value}")
        )
        
        self.puzzle_layout.addWidget(QLabel("Challenge Description:"))
        puzzle_desc = QLabel("Bitcoin Puzzle Challenges were created to reward\n"
                             "people who solve private keys in specific ranges.")
        puzzle_desc.setWordWrap(True)
        self.puzzle_layout.addWidget(puzzle_desc)
        
        self.attack_layout.addWidget(self.puzzle_frame)
        self.puzzle_frame.setVisible(False)
        
        # Pattern Search options
        self.pattern_frame = QFrame()
        self.pattern_layout = QVBoxLayout(self.pattern_frame)
        self.pattern_layout.addWidget(QLabel("Pattern Type:"))
        
        self.pattern_type_group = QButtonGroup(self)
        self.prefix_radio = QRadioButton("Address Prefix")
        self.suffix_radio = QRadioButton("Address Suffix")
        self.vanity_radio = QRadioButton("Vanity Pattern")
        self.repeat_radio = QRadioButton("Repeated Characters")
        
        self.prefix_radio.setChecked(True)
        self.pattern_type_group.addButton(self.prefix_radio)
        self.pattern_type_group.addButton(self.suffix_radio)
        self.pattern_type_group.addButton(self.vanity_radio)
        self.pattern_type_group.addButton(self.repeat_radio)
        
        self.pattern_layout.addWidget(self.prefix_radio)
        self.pattern_layout.addWidget(self.suffix_radio)
        self.pattern_layout.addWidget(self.vanity_radio)
        self.pattern_layout.addWidget(self.repeat_radio)
        
        self.pattern_layout.addWidget(QLabel("Pattern Text:"))
        self.pattern_text_input = QLineEdit("1")
        self.pattern_layout.addWidget(self.pattern_text_input)
        
        self.case_sensitive_checkbox = QCheckBox("Case Sensitive")
        self.pattern_layout.addWidget(self.case_sensitive_checkbox)
        
        self.pattern_layout.addWidget(QLabel("Advanced Pattern Options:"))
        self.pattern_complexity_combo = QComboBox()
        self.pattern_complexity_combo.addItems(["Simple", "Regex (Advanced)", "Multi-pattern"])
        self.pattern_layout.addWidget(self.pattern_complexity_combo)
        
        self.attack_layout.addWidget(self.pattern_frame)
        self.pattern_frame.setVisible(False)
        
        # Range Splitting options
        self.range_frame = QFrame()
        self.range_layout = QVBoxLayout(self.range_frame)
        self.range_layout.addWidget(QLabel("End Key (int):"))
        self.range_end_input = QLineEdit("1000000")
        self.range_layout.addWidget(self.range_end_input)
        
        self.range_layout.addWidget(QLabel("Split into chunks:"))
        
        self.range_chunks_slider = QSlider(Qt.Orientation.Horizontal if PYQT_VERSION == 6 else Qt.Horizontal)
        self.range_chunks_slider.setMinimum(1)
        self.range_chunks_slider.setMaximum(16)
        self.range_chunks_slider.setValue(4)
        self.range_chunks_label = QLabel("4 chunks")
        
        range_slider_layout = QHBoxLayout()
        range_slider_layout.addWidget(self.range_chunks_slider)
        range_slider_layout.addWidget(self.range_chunks_label)
        self.range_layout.addLayout(range_slider_layout)
        
        self.range_chunks_slider.valueChanged.connect(
            lambda value: self.range_chunks_label.setText(f"{value} chunks")
        )
        
        self.range_layout.addWidget(QLabel("Distribution Strategy:"))
        self.range_strategy_combo = QComboBox()
        self.range_strategy_combo.addItems(["Linear", "Logarithmic", "Random", "Weighted"])
        self.range_layout.addWidget(self.range_strategy_combo)
        
        self.range_layout.addWidget(QLabel("Range Description:"))
        range_desc = QLabel("Split a range of private keys into multiple chunks for distributed processing.")
        range_desc.setWordWrap(True)
        self.range_layout.addWidget(range_desc)
        
        self.attack_layout.addWidget(self.range_frame)
        self.range_frame.setVisible(False)
        
        # Connect attack mode radios to show/hide specific settings
        self.default_mode_radio.toggled.connect(self.update_attack_mode_ui)
        self.puzzle_mode_radio.toggled.connect(self.update_attack_mode_ui)
        self.pattern_mode_radio.toggled.connect(self.update_attack_mode_ui)
        self.range_mode_radio.toggled.connect(self.update_attack_mode_ui)
        
        # Address format
        self.address_format_label = QLabel("🏷️ Address Format:")
        self.address_format_label.setStyleSheet("font-weight: bold;")
        self.attack_layout.addWidget(self.address_format_label)
        
        self.format_group = QButtonGroup(self)
        self.p2pkh_radio = QRadioButton("P2PKH (default, legacy)")
        self.p2wpkh_radio = QRadioButton("P2WPKH (SegWit)")
        
        self.p2pkh_radio.setChecked(True)
        self.format_group.addButton(self.p2pkh_radio)
        self.format_group.addButton(self.p2wpkh_radio)
        
        self.attack_layout.addWidget(self.p2pkh_radio)
        self.attack_layout.addWidget(self.p2wpkh_radio)
        
        # Balance threshold
        self.attack_layout.addWidget(QLabel("💵 Minimum Balance (BTC):"))
        self.min_balance_input = QLineEdit("0.001")
        self.attack_layout.addWidget(self.min_balance_input)
        
        self.sidebar_layout.addWidget(self.attack_frame)
        
        # Settings section
        self.settings_frame = QFrame()
        self.settings_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.settings_layout = QVBoxLayout(self.settings_frame)
        
        self.settings_label = QLabel("⚙️ Settings")
        self.settings_label.setStyleSheet("font-weight: bold; font-size: 16px;")
        self.settings_layout.addWidget(self.settings_label)
        
        # Settings tabs for better organization
        self.settings_tabs = QTabWidget()
        
        # Performance Settings Tab
        self.perf_tab = QWidget()
        self.perf_layout = QVBoxLayout(self.perf_tab)
        
        # Batch size settings
        self.perf_layout.addWidget(QLabel("Batch Size:"))
        self.batch_size_group = QButtonGroup(self)
        self.auto_batch_radio = QRadioButton("Auto (Recommended)")
        self.small_batch_radio = QRadioButton("Small (Better UI)")
        self.medium_batch_radio = QRadioButton("Medium")
        self.large_batch_radio = QRadioButton("Large (Better Performance)")
        self.custom_batch_radio = QRadioButton("Custom")
        
        self.auto_batch_radio.setChecked(True)
        self.batch_size_group.addButton(self.auto_batch_radio)
        self.batch_size_group.addButton(self.small_batch_radio)
        self.batch_size_group.addButton(self.medium_batch_radio)
        self.batch_size_group.addButton(self.large_batch_radio)
        self.batch_size_group.addButton(self.custom_batch_radio)
        
        self.perf_layout.addWidget(self.auto_batch_radio)
        self.perf_layout.addWidget(self.small_batch_radio)
        self.perf_layout.addWidget(self.medium_batch_radio)
        self.perf_layout.addWidget(self.large_batch_radio)
        self.perf_layout.addWidget(self.custom_batch_radio)
        
        # Custom batch size entry (initially hidden)
        self.custom_batch_frame = QFrame()
        self.custom_batch_layout = QHBoxLayout(self.custom_batch_frame)
        self.custom_batch_input = QLineEdit("1024")
        self.custom_batch_layout.addWidget(self.custom_batch_input)
        self.perf_layout.addWidget(self.custom_batch_frame)
        self.custom_batch_frame.setVisible(False)
        
        self.custom_batch_radio.toggled.connect(lambda checked: self.custom_batch_frame.setVisible(checked))
        
        # Thread settings
        self.perf_layout.addWidget(QLabel("CPU Threads:"))
        self.thread_count_slider = QSlider(Qt.Orientation.Horizontal if PYQT_VERSION == 6 else Qt.Horizontal)
        self.thread_count_slider.setMinimum(1)
        self.thread_count_slider.setMaximum(16)
        self.thread_count_slider.setValue(4)
        self.thread_count_label = QLabel("4 threads")
        
        thread_layout = QHBoxLayout()
        thread_layout.addWidget(self.thread_count_slider)
        thread_layout.addWidget(self.thread_count_label)
        self.perf_layout.addLayout(thread_layout)
        
        self.thread_count_slider.valueChanged.connect(
            lambda value: self.thread_count_label.setText(f"{value} threads")
        )
        
        # Memory usage settings
        self.perf_layout.addWidget(QLabel("Memory Usage:"))
        self.memory_usage_combo = QComboBox()
        self.memory_usage_combo.addItems(["Low", "Medium", "High", "Maximum"])
        self.memory_usage_combo.setCurrentIndex(1)  # Medium by default
        self.perf_layout.addWidget(self.memory_usage_combo)
        
        # Update frequency
        self.perf_layout.addWidget(QLabel("UI Update Frequency:"))
        self.update_freq_slider = QSlider(Qt.Orientation.Horizontal if PYQT_VERSION == 6 else Qt.Horizontal)
        self.update_freq_slider.setMinimum(1)
        self.update_freq_slider.setMaximum(10)
        self.update_freq_slider.setValue(5)
        self.update_freq_label = QLabel("0.5 seconds")
        
        update_layout = QHBoxLayout()
        update_layout.addWidget(self.update_freq_slider)
        update_layout.addWidget(self.update_freq_label)
        self.perf_layout.addLayout(update_layout)
        
        self.update_freq_slider.valueChanged.connect(
            lambda value: self.update_freq_label.setText(f"{value/10:.1f} seconds")
        )
        
        # API Settings Tab
        self.api_tab = QWidget()
        self.api_layout = QVBoxLayout(self.api_tab)
        
        self.api_layout.addWidget(QLabel("Blockchain API:"))
        self.api_combo = QComboBox()
        self.api_combo.addItems(["Blockstream", "Blockchain.info", "Blockcypher", "Custom"])
        self.api_layout.addWidget(self.api_combo)
        
        self.api_layout.addWidget(QLabel("Custom API URL (if selected):"))
        self.custom_api_input = QLineEdit()
        self.custom_api_input.setPlaceholderText("https://api.example.com/v1/")
        self.api_layout.addWidget(self.custom_api_input)
        
        self.api_layout.addWidget(QLabel("API Key (if required):"))
        self.api_key_input = QLineEdit()
        self.api_layout.addWidget(self.api_key_input)
        
        # API Options
        self.api_layout.addWidget(QLabel("API Options:"))
        self.api_timeout_layout = QHBoxLayout()
        self.api_timeout_layout.addWidget(QLabel("Timeout (seconds):"))
        self.api_timeout_spin = QSpinBox()
        self.api_timeout_spin.setMinimum(1)
        self.api_timeout_spin.setMaximum(60)
        self.api_timeout_spin.setValue(10)
        self.api_timeout_layout.addWidget(self.api_timeout_spin)
        self.api_layout.addLayout(self.api_timeout_layout)
        
        self.api_retries_layout = QHBoxLayout()
        self.api_retries_layout.addWidget(QLabel("Max retries:"))
        self.api_retries_spin = QSpinBox()
        self.api_retries_spin.setMinimum(0)
        self.api_retries_spin.setMaximum(10)
        self.api_retries_spin.setValue(3)
        self.api_retries_layout.addWidget(self.api_retries_spin)
        self.api_layout.addLayout(self.api_retries_layout)
        
        self.check_balance_checkbox = QCheckBox("Check balance for matches")
        self.check_balance_checkbox.setChecked(True)
        self.api_layout.addWidget(self.check_balance_checkbox)
        
        # Display Settings Tab
        self.display_tab = QWidget()
        self.display_layout = QVBoxLayout(self.display_tab)
        
        # Theme settings
        self.display_layout.addWidget(QLabel("Theme:"))
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["System", "Light", "Dark", "High Contrast"])
        self.display_layout.addWidget(self.theme_combo)
        
        # Display options
        self.display_layout.addWidget(QLabel("Display Options:"))
        self.show_private_keys_checkbox = QCheckBox("Show private keys in results")
        self.show_private_keys_checkbox.setChecked(True)
        self.display_layout.addWidget(self.show_private_keys_checkbox)
        
        self.show_addr_checkbox = QCheckBox("Show current address during brute force")
        self.show_addr_checkbox.setChecked(True)
        self.display_layout.addWidget(self.show_addr_checkbox)
        
        self.compact_display_checkbox = QCheckBox("Use compact display format")
        self.display_layout.addWidget(self.compact_display_checkbox)
        
        self.display_layout.addWidget(QLabel("Font Size:"))
        self.font_size_slider = QSlider(Qt.Orientation.Horizontal if PYQT_VERSION == 6 else Qt.Horizontal)
        self.font_size_slider.setMinimum(8)
        self.font_size_slider.setMaximum(16)
        self.font_size_slider.setValue(10)
        self.font_size_label = QLabel("10 pt")
        
        font_layout = QHBoxLayout()
        font_layout.addWidget(self.font_size_slider)
        font_layout.addWidget(self.font_size_label)
        self.display_layout.addLayout(font_layout)
        
        self.font_size_slider.valueChanged.connect(
            lambda value: self.font_size_label.setText(f"{value} pt")
        )
        
        # Advanced Settings Tab
        self.advanced_tab = QWidget()
        self.advanced_layout = QVBoxLayout(self.advanced_tab)
        
        # Advanced settings
        self.advanced_layout.addWidget(QLabel("Logging Level:"))
        self.log_level_combo = QComboBox()
        self.log_level_combo.addItems(["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"])
        self.log_level_combo.setCurrentIndex(1)  # INFO by default
        self.advanced_layout.addWidget(self.log_level_combo)
        
        self.advanced_layout.addWidget(QLabel("Logs Directory:"))
        self.log_dir_layout = QHBoxLayout()
        self.log_dir_input = QLineEdit()
        self.log_dir_input.setReadOnly(True)
        self.log_dir_browse = QPushButton("Browse...")
        self.log_dir_layout.addWidget(self.log_dir_input)
        self.log_dir_layout.addWidget(self.log_dir_browse)
        self.advanced_layout.addLayout(self.log_dir_layout)
        
        # Load base directory for logs
        base_dir = Path(__file__).parent.parent.parent
        logs_dir = base_dir / "smore" / "logs"
        self.log_dir_input.setText(str(logs_dir))
        
        # Bloom filter size setting
        self.advanced_layout.addWidget(QLabel("Bloom Filter Size:"))
        self.bloom_size_combo = QComboBox()
        self.bloom_size_combo.addItems(["Small", "Medium", "Large", "X-Large"])
        self.bloom_size_combo.setCurrentIndex(1)  # Medium by default
        self.advanced_layout.addWidget(self.bloom_size_combo)
        
        # Auto-save settings
        self.advanced_layout.addWidget(QLabel("Auto-save Interval (seconds):"))
        self.autosave_spin = QSpinBox()
        self.autosave_spin.setMinimum(0)
        self.autosave_spin.setMaximum(3600)
        self.autosave_spin.setValue(300)  # 5 minutes
        self.advanced_layout.addWidget(self.autosave_spin)
        
        # Add performance profiling option
        self.enable_profiling_checkbox = QCheckBox("Enable performance profiling")
        self.advanced_layout.addWidget(self.enable_profiling_checkbox)
        
        # Add all tabs to settings tabwidget
        self.settings_tabs.addTab(self.perf_tab, "Performance")
        self.settings_tabs.addTab(self.api_tab, "API")
        self.settings_tabs.addTab(self.display_tab, "Display")
        self.settings_tabs.addTab(self.advanced_tab, "Advanced")
        
        self.settings_layout.addWidget(self.settings_tabs)
        
        # Add settings frame to sidebar
        self.sidebar_layout.addWidget(self.settings_frame)
        
        # Control buttons
        self.control_frame = QFrame()
        self.control_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.control_layout = QVBoxLayout(self.control_frame)
        
        self.start_button = QPushButton("▶️ Start")
        self.start_button.setMinimumHeight(40)
        self.start_button.setStyleSheet("background-color: #28a745; color: white; font-weight: bold;")
        self.start_button.clicked.connect(self.start_brute_force)
        self.control_layout.addWidget(self.start_button)
        
        self.stop_button = QPushButton("⏹ Stop")
        self.stop_button.setMinimumHeight(40)
        self.stop_button.setStyleSheet("background-color: #dc3545; color: white; font-weight: bold;")
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop_brute_force)
        self.control_layout.addWidget(self.stop_button)
        
        self.export_button = QPushButton("📤 Export Results")
        self.export_button.clicked.connect(self.export_results)
        self.control_layout.addWidget(self.export_button)
        
        self.sidebar_layout.addWidget(self.control_frame)
        
        # Add spacer at the bottom
        self.sidebar_layout.addStretch()
    
    def create_content_ui(self):
        """Create the main content area UI components."""
        # Dashboard (stats display)
        self.dashboard = QFrame()
        self.dashboard.setFrameShape(QFrame.Shape.StyledPanel)
        self.dashboard.setMinimumHeight(200)
        self.dashboard_layout = QGridLayout(self.dashboard)
        
        # Create dashboard elements (stats, current key, etc.)
        self.key_label = QLabel("Current Private Key:")
        self.dashboard_layout.addWidget(self.key_label, 0, 0)
        self.key_value = QLabel("0x0000000000000000000000000000000000000000000000000000000000000001")
        self.dashboard_layout.addWidget(self.key_value, 0, 1)
        
        self.address_label = QLabel("Current Address:")
        self.dashboard_layout.addWidget(self.address_label, 1, 0)
        self.address_value = QLabel("1BitcoinEaterAddressDontSendf59kuE")
        self.dashboard_layout.addWidget(self.address_value, 1, 1)
        
        self.speed_label = QLabel("Speed:")
        self.dashboard_layout.addWidget(self.speed_label, 2, 0)
        self.speed_value = QLabel("0 keys/s")
        self.dashboard_layout.addWidget(self.speed_value, 2, 1)
        
        self.matches_label = QLabel("Matches Found:")
        self.dashboard_layout.addWidget(self.matches_label, 3, 0)
        self.matches_value = QLabel("0")
        self.dashboard_layout.addWidget(self.matches_value, 3, 1)
        
        self.content_layout.addWidget(self.dashboard)
        
        # Tabs section
        self.tabs = QTabWidget()
        
        # Results tab
        self.results_tab = QScrollArea()
        self.results_tab.setWidgetResizable(True)
        self.results_container = QWidget()
        self.results_layout = QVBoxLayout(self.results_container)
        self.results_layout.addWidget(QLabel("No results yet. Start a brute force attack to find matches."))
        self.results_layout.addStretch()
        self.results_tab.setWidget(self.results_container)
        
        # Log tab
        self.log_tab = QWidget()
        self.log_layout = QVBoxLayout(self.log_tab)
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_layout.addWidget(self.log_text)
        
        # Add tabs
        self.tabs.addTab(self.results_tab, "Results")
        self.tabs.addTab(self.log_tab, "Logs")
        
        self.content_layout.addWidget(self.tabs)
    
    def setup_thread_connections(self):
        """Set up connections to the brute force thread."""
        # Connect thread signals to UI update slots
        self.brute_force_thread.status_update.connect(self.update_status)
        self.brute_force_thread.progress_update.connect(self.update_progress)
        self.brute_force_thread.match_found.connect(self.on_match_found)
        self.brute_force_thread.finished.connect(self.on_brute_force_finished)
    
    def init_backend(self):
        """Initialize backend components."""
        # Initialize GPU accelerator
        self.gpu_accelerator = self.brute_force_thread.gpu_accelerator
        
        # Check for GPU
        gpu_info = self.gpu_accelerator.detect_gpu()
        if gpu_info:
            self.update_status(f"GPU detected: {gpu_info.get('name', 'Unknown GPU')}")
            self.update_log(f"Using GPU: {gpu_info.get('name', 'Unknown GPU')}")
        else:
            self.update_status("No GPU detected, falling back to CPU mode")
            self.update_log("No GPU detected, using CPU mode")
        
        # Load progress
        self.load_progress()
    
    def update_status(self, message):
        """Update the status bar with a message."""
        self.statusBar().showMessage(message)
    
    def update_log(self, message):
        """Append message to log text widget."""
        self.log_text.append(f"{message}")
    
    def update_progress(self, progress_data):
        """Update the UI with progress data."""
        # Update dashboard values
        self.key_value.setText(hex(progress_data.get("current_key", 1)))
        self.address_value.setText(progress_data.get("current_address", ""))
        self.speed_value.setText(f"{progress_data.get('keys_per_second', 0):.2f} keys/s")
        self.matches_value.setText(str(len(self.matches)))
    
    def on_match_found(self, wallet_data):
        """Handle a match being found."""
        # Add to matches list
        self.matches.append(wallet_data)
        
        # Update UI
        self.matches_value.setText(str(len(self.matches)))
        
        # Log the match
        address = wallet_data.get('p2pkh_address', '')
        self.update_log(f"Match found! Address: {address}")
        
        # Show notification
        QMessageBox.information(self, "Match Found", f"Match found for address {address}")
        
        # Add to results tab (simplified)
        result_card = QFrame()
        result_card.setFrameShape(QFrame.Shape.StyledPanel)
        result_layout = QVBoxLayout(result_card)
        
        result_layout.addWidget(QLabel(f"Address: {address}"))
        result_layout.addWidget(QLabel(f"Private Key: {wallet_data.get('private_key_hex', '')}"))
        
        self.results_layout.insertWidget(0, result_card)
    
    def on_brute_force_finished(self):
        """Handle the brute force operation finishing."""
        self.update_status("Brute force attack stopped")
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
    
    def load_target_addresses(self):
        """Load target addresses from a file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select address list file", "", "Text files (*.txt);;All files (*.*)"
        )
        
        if not file_path:
            return
            
        try:
            with open(file_path, 'r') as file:
                addresses = set(line.strip() for line in file if line.strip())
                
            self.target_addresses.update(addresses)
            self.address_count_label.setText(f"{len(self.target_addresses)} addresses loaded")
            self.update_log(f"Loaded {len(addresses)} addresses from {file_path}")
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load addresses: {str(e)}")
    
    def start_brute_force(self):
        """Start the brute force attack."""
        # Get addresses from text box
        if self.address_text.toPlainText():
            manual_addresses = set(addr.strip() for addr in self.address_text.toPlainText().split('\n') if addr.strip())
            self.target_addresses.update(manual_addresses)
            self.address_count_label.setText(f"{len(self.target_addresses)} addresses loaded")
        
        # Check if we have target addresses
        if not self.target_addresses:
            QMessageBox.warning(self, "Warning", "No target addresses specified")
            return
        
        # Determine attack mode
        attack_mode = "Default"
        if self.puzzle_mode_radio.isChecked():
            attack_mode = "Puzzle"
        elif self.pattern_mode_radio.isChecked():
            attack_mode = "Pattern"
        elif self.range_mode_radio.isChecked():
            attack_mode = "Range"
            
        # Determine address format
        address_format = "P2PKH"
        if self.p2wpkh_radio.isChecked():
            address_format = "P2WPKH"
            
        # Get batch size
        batch_size = 0  # Auto
        if self.small_batch_radio.isChecked():
            batch_size = 256
        elif self.medium_batch_radio.isChecked():
            batch_size = 1024
        elif self.large_batch_radio.isChecked():
            batch_size = 4096
        elif self.custom_batch_radio.isChecked():
            try:
                batch_size = max(64, int(self.custom_batch_input.text()))
            except ValueError:
                batch_size = 1024
        
        # Get start key
        try:
            start_key = int(self.start_key_input.text())
        except ValueError:
            start_key = 1
            
        # Get min balance
        try:
            min_balance = float(self.min_balance_input.text())
        except ValueError:
            min_balance = 0.001
            
        # Prepare settings
        settings = {
            "start_key": start_key,
            "target_addresses": self.target_addresses,
            "address_format": address_format,
            "attack_settings": {
                "attack_mode": attack_mode,
                "batch_size": batch_size,
                "min_balance": min_balance,
                "thread_count": self.thread_count_slider.value(),
                "update_frequency": self.update_freq_slider.value() / 10.0,
                "check_balance": self.check_balance_checkbox.isChecked(),
                "api_settings": {
                    "provider": self.api_combo.currentText(),
                    "custom_url": self.custom_api_input.text(),
                    "api_key": self.api_key_input.text(),
                    "timeout": self.api_timeout_spin.value(),
                    "max_retries": self.api_retries_spin.value()
                }
            }
        }
        
        # Add mode-specific settings
        if attack_mode == "Puzzle":
            settings["attack_settings"]["puzzle_level"] = self.puzzle_level_slider.value()
        elif attack_mode == "Pattern":
            pattern_type = "prefix"
            if self.suffix_radio.isChecked():
                pattern_type = "suffix"
            elif self.vanity_radio.isChecked():
                pattern_type = "vanity"
            elif self.repeat_radio.isChecked():
                pattern_type = "repeat"
                
            settings["attack_settings"]["pattern_type"] = pattern_type
            settings["attack_settings"]["pattern_text"] = self.pattern_text_input.text()
            settings["attack_settings"]["case_sensitive"] = self.case_sensitive_checkbox.isChecked()
            settings["attack_settings"]["pattern_complexity"] = self.pattern_complexity_combo.currentText()
        elif attack_mode == "Range":
            try:
                end_key = int(self.range_end_input.text())
            except ValueError:
                end_key = start_key + 1000000
                
            settings["attack_settings"]["end_key"] = end_key
            settings["attack_settings"]["range_chunks"] = self.range_chunks_slider.value()
            settings["attack_settings"]["distribution_strategy"] = self.range_strategy_combo.currentText()
        
        # Start brute force
        if self.brute_force_thread.start_brute_force(settings):
            self.start_button.setEnabled(False)
            self.stop_button.setEnabled(True)
            self.update_status("Running brute force attack...")
            self.update_log(f"Started brute force attack with {len(self.target_addresses)} target addresses")
    
    def stop_brute_force(self):
        """Stop the brute force attack."""
        if self.brute_force_thread.stop_brute_force():
            self.update_status("Stopping brute force attack...")
            self.update_log("Stopping brute force attack...")
    
    def export_results(self):
        """Export results to a file."""
        if not self.matches:
            QMessageBox.information(self, "No Results", "No matches found to export")
            return
            
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Export Results", "", "Text files (*.txt);;CSV files (*.csv);;JSON files (*.json);;All files (*.*)"
        )
        
        if not file_path:
            return
            
        try:
            success = self.brute_force_thread.logger.export_results(file_path)
            
            if success:
                QMessageBox.information(self, "Export Successful", f"Results exported to {file_path}")
                self.update_log(f"Exported results to {file_path}")
            else:
                QMessageBox.critical(self, "Export Failed", "Failed to export results")
        except Exception as e:
            QMessageBox.critical(self, "Export Failed", f"Error exporting results: {str(e)}")
    
    def load_progress(self):
        """Load progress from a previous run."""
        progress_data = self.brute_force_thread.logger.load_progress()
        
        if progress_data:
            current_key = progress_data.get('current_key', 1)
            self.update_log(f"Loaded previous progress: Current key = {current_key}")

    def closeEvent(self, event):
        """Handle window close event."""
        if self.brute_force_thread.running:
            reply = QMessageBox.question(
                self, "Quit", "Brute force is still running. Do you want to stop and quit?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            
            if reply == QMessageBox.StandardButton.Yes:
                self.brute_force_thread.stop_brute_force()
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()

    def update_attack_mode_ui(self):
        """Update UI based on selected attack mode."""
        # Hide all specialized frames first
        self.puzzle_frame.setVisible(False)
        self.pattern_frame.setVisible(False)
        self.range_frame.setVisible(False)
        
        # Show the appropriate frame based on selection
        if self.puzzle_mode_radio.isChecked():
            self.puzzle_frame.setVisible(True)
        elif self.pattern_mode_radio.isChecked():
            self.pattern_frame.setVisible(True)
        elif self.range_mode_radio.isChecked():
            self.range_frame.setVisible(True)
            
        # Adjust the layout to accommodate the new frames
        self.attack_frame.adjustSize()
        self.sidebar_layout.update()

def start_qt_app(args=None):
    """Start the PyQt application."""
    # Create application instance
    app = QApplication(sys.argv)
    
    # Load stylesheet for modern appearance
    app.setStyle("Fusion")
    
    # Create main window
    main_window = SmoreMainWindow()
    main_window.show()
    
    # Run the application
    return app.exec() if hasattr(app, 'exec') else app.exec_()

if __name__ == "__main__":
    # Run the application when script is executed directly
    sys.exit(start_qt_app()) 