import os
import time
import customtkinter as ctk
from typing import Dict, Any, Optional
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib
import numpy as np
from datetime import datetime

# Configure matplotlib for dark mode
matplotlib.use("TkAgg")
plt.style.use('dark_background')

class DashboardFrame(ctk.CTkFrame):
    """
    Dashboard frame displaying real-time brute force statistics and metrics.
    """
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        
        # Configure grid layout
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(3, weight=1)  # Make charts expandable
        
        # Create title
        self.title_label = ctk.CTkLabel(
            self, 
            text="Real-time Monitoring Dashboard", 
            font=ctk.CTkFont(size=20, weight="bold")
        )
        self.title_label.grid(row=0, column=0, columnspan=2, padx=20, pady=(20, 10), sticky="nw")
        
        # Create modern stat boxes
        self.create_stat_boxes()
        
        # Create charts
        self.create_charts()
        
        # Initialize data for charts
        self.time_data = []
        self.rate_data = []
        self.start_time = time.time()
        
        # Update charts on first run
        self.after(100, self.update_charts)
    
    def create_stat_boxes(self):
        """Create modern statistics display boxes."""
        # Current key - Card 1
        self.key_frame = ctk.CTkFrame(self, corner_radius=10, fg_color=("#EEEEEE", "#333333"))
        self.key_frame.grid(row=1, column=0, padx=(20, 10), pady=10, sticky="ew")
        
        self.key_label = ctk.CTkLabel(
            self.key_frame, 
            text="🔑 Current Private Key", 
            font=ctk.CTkFont(size=14, weight="bold"),
            anchor="w"
        )
        self.key_label.pack(anchor="w", padx=15, pady=(15, 5), fill="x")
        
        self.key_value = ctk.CTkLabel(
            self.key_frame, 
            text="0", 
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color=("#FF6B35", "#FF6B35")
        )
        self.key_value.pack(anchor="w", padx=15, pady=(0, 15))
        
        # Current address - Card 2
        self.address_frame = ctk.CTkFrame(self, corner_radius=10, fg_color=("#EEEEEE", "#333333"))
        self.address_frame.grid(row=1, column=1, padx=(10, 20), pady=10, sticky="ew")
        
        self.address_label = ctk.CTkLabel(
            self.address_frame, 
            text="🏷️ Current Address", 
            font=ctk.CTkFont(size=14, weight="bold"),
            anchor="w"
        )
        self.address_label.pack(anchor="w", padx=15, pady=(15, 5), fill="x")
        
        self.address_value = ctk.CTkLabel(
            self.address_frame, 
            text="--", 
            font=ctk.CTkFont(size=12),
            anchor="w",
            wraplength=300
        )
        self.address_value.pack(anchor="w", padx=15, pady=(0, 15), fill="x")
        
        # Keys per second - Card 3
        self.rate_frame = ctk.CTkFrame(self, corner_radius=10, fg_color=("#EEEEEE", "#333333"))
        self.rate_frame.grid(row=2, column=0, padx=(20, 10), pady=10, sticky="ew")
        
        self.rate_label = ctk.CTkLabel(
            self.rate_frame, 
            text="⚡ Keys Per Second", 
            font=ctk.CTkFont(size=14, weight="bold"),
            anchor="w"
        )
        self.rate_label.pack(anchor="w", padx=15, pady=(15, 5), fill="x")
        
        self.rate_value = ctk.CTkLabel(
            self.rate_frame, 
            text="0", 
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color=("#22bb33", "#22bb33")
        )
        self.rate_value.pack(anchor="w", padx=15, pady=(0, 15))
        
        # Matches found - Card 4
        self.matches_frame = ctk.CTkFrame(self, corner_radius=10, fg_color=("#EEEEEE", "#333333"))
        self.matches_frame.grid(row=2, column=1, padx=(10, 20), pady=10, sticky="ew")
        
        self.matches_label = ctk.CTkLabel(
            self.matches_frame, 
            text="💰 Matches Found", 
            font=ctk.CTkFont(size=14, weight="bold"),
            anchor="w"
        )
        self.matches_label.pack(anchor="w", padx=15, pady=(15, 5), fill="x")
        
        # Create a horizontal layout for matches and balance
        matches_layout = ctk.CTkFrame(self.matches_frame, fg_color="transparent")
        matches_layout.pack(fill="x", padx=15, pady=(0, 15))
        
        self.matches_value = ctk.CTkLabel(
            matches_layout, 
            text="0", 
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color=("#FF6B35", "#FF6B35")
        )
        self.matches_value.pack(side="left")
        
        self.balance_value = ctk.CTkLabel(
            matches_layout, 
            text="(Total: 0.00000000 BTC)", 
            font=ctk.CTkFont(size=12),
            text_color=("#888888", "#888888")
        )
        self.balance_value.pack(side="left", padx=(10, 0), pady=(7, 0))
    
    def create_charts(self):
        """Create performance charts with modern styling."""
        # Create frame for charts
        self.charts_frame = ctk.CTkFrame(self, corner_radius=10)
        self.charts_frame.grid(row=3, column=0, columnspan=2, padx=20, pady=10, sticky="nsew")
        
        # Configure grid for charts frame
        self.charts_frame.grid_columnconfigure(0, weight=1)
        self.charts_frame.grid_rowconfigure(0, weight=0)
        self.charts_frame.grid_rowconfigure(1, weight=1)
        
        # Chart title
        chart_title = ctk.CTkLabel(
            self.charts_frame,
            text="Performance Monitoring",
            font=ctk.CTkFont(size=16, weight="bold")
        )
        chart_title.grid(row=0, column=0, padx=15, pady=(15, 5), sticky="w")
        
        # Chart container
        chart_container = ctk.CTkFrame(self.charts_frame, fg_color="transparent")
        chart_container.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
        
        # Create a matplotlib figure for the performance chart
        self.figure, self.ax = plt.subplots(figsize=(8, 4), dpi=100)
        
        # Style the plot for dark theme
        self.ax.set_facecolor('#1E1E1E')
        self.figure.patch.set_facecolor('#2B2B2B')
        
        # Configure plot
        self.ax.set_title("Keys Per Second", color='white', fontsize=12)
        self.ax.set_xlabel("Time (s)", color='white', fontsize=10)
        self.ax.set_ylabel("Keys/s", color='white', fontsize=10)
        self.ax.tick_params(colors='white', labelsize=8)
        self.ax.grid(True, linestyle='--', alpha=0.3, color='#666666')
        
        # Remove spines
        for spine in self.ax.spines.values():
            spine.set_color('#444444')
        
        # Create canvas for matplotlib figure
        self.canvas = FigureCanvasTkAgg(self.figure, master=chart_container)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)
    
    def update_stats(self, 
                    current_key: int, 
                    current_address: str, 
                    keys_per_second: float, 
                    matches_found: int, 
                    total_balance: float) -> None:
        """
        Update dashboard statistics with current values.
        
        Args:
            current_key: Current private key being tested
            current_address: Current Bitcoin address being tested
            keys_per_second: Performance in keys per second
            matches_found: Number of matches found
            total_balance: Total balance of all matches in BTC
        """
        # Format numbers for better readability
        formatted_key = f"{current_key:,}"
        formatted_rate = f"{keys_per_second:,.2f}"
        
        # Update stat boxes
        self.key_value.configure(text=formatted_key)
        self.address_value.configure(text=f"{current_address if current_address else '--'}")
        self.rate_value.configure(text=formatted_rate)
        self.matches_value.configure(text=str(matches_found))
        self.balance_value.configure(text=f"(Total: {total_balance:.8f} BTC)")
        
        # Update chart data
        current_time = time.time() - self.start_time
        self.time_data.append(current_time)
        self.rate_data.append(keys_per_second)
        
        # Limit data points to prevent memory issues
        if len(self.time_data) > 300:  # Keep last 5 minutes at 1 point per second
            self.time_data = self.time_data[-300:]
            self.rate_data = self.rate_data[-300:]
    
    def update_charts(self):
        """Update performance charts with current data."""
        if len(self.time_data) > 1:
            # Clear previous plot
            self.ax.clear()
            
            # Plot new data with improved styling
            self.ax.plot(self.time_data, self.rate_data, color='#FF6B35', linewidth=2)
            
            # Fill area under the curve
            self.ax.fill_between(self.time_data, self.rate_data, color='#FF6B35', alpha=0.2)
            
            # Update aesthetics
            self.ax.set_title("Keys Per Second", color='white', fontsize=12)
            self.ax.set_xlabel("Time (s)", color='white', fontsize=10)
            self.ax.set_ylabel("Keys/s", color='white', fontsize=10)
            self.ax.tick_params(colors='white', labelsize=8)
            self.ax.grid(True, linestyle='--', alpha=0.3, color='#666666')
            
            # Set dynamic y-axis limit with 10% padding
            if max(self.rate_data) > 0:
                self.ax.set_ylim([0, max(self.rate_data) * 1.1])
            
            # Remove spines
            for spine in self.ax.spines.values():
                spine.set_color('#444444')
            
            # Redraw canvas
            self.canvas.draw()
        
        # Schedule next update
        self.after(1000, self.update_charts) 