import os
import time
import json
import logging
import threading
import tkinter as tk
from tkinter import filedialog, messagebox
from typing import Set, List, Dict, Any, Optional
import customtkinter as ctk
from PIL import Image
import sys
import webbrowser
from pathlib import Path

# Import handling for running from any directory
try:
    from smore.utils import BitcoinWallet, GPUAccelerator, BruteForceLogger
    from smore.gui.dashboard import DashboardFrame
    from smore.gui.sidebar import SidebarFrame
    from smore.gui.gpu_tab import GPUTabFrame
    from smore.gui.results_tab import ResultsTabFrame
except ImportError:
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from utils import BitcoinWallet, GPUAccelerator, BruteForceLogger
    from gui.dashboard import DashboardFrame
    from gui.sidebar import SidebarFrame
    from gui.gpu_tab import GPUTabFrame
    from gui.results_tab import ResultsTabFrame

# Configure logger
logger = logging.getLogger(__name__)

class BruteForceApp(ctk.CTk):
    """
    Main application class for Smore: Bitcoin Wallet Brute-force Tool.
    """
    def __init__(self, root=None):
        # Initialize without using the provided root
        super().__init__()
        
        if root:
            # If root was provided by splash screen, destroy it
            # as we're creating our own window
            try:
                root.destroy()
            except:
                pass
        
        # Configure window
        self.title("Smore: Bitcoin Wallet Brute-force Tool")
        self.geometry("1280x800")
        self.minsize(1000, 700)
        
        # Set up exception handling
        self._setup_exception_handling()
        
        # Initialize components with placeholder
        self.sidebar = None
        self.dashboard = None
        self.gpu_tab = None
        self.results_tab = None
        self.log_text = None
        self.status_label = None
        
        # Application state
        self.running = False
        self.stop_event = threading.Event()
        self.target_addresses = set()
        self.matches = []
        self.current_key = 1  # Start with 1 by default
        self.current_address = ""
        self.keys_per_second = 0
        self.total_balance = 0.0
        self.update_thread = None
        
        # Get the path to the smore package
        package_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        logs_dir = os.path.join(package_dir, "logs")
        
        # Ensure logs directory exists
        os.makedirs(logs_dir, exist_ok=True)
        
        # Create assets directory if it doesn't exist
        assets_dir = Path(package_dir) / "assets"
        assets_dir.mkdir(exist_ok=True)
        
        # Initialize utility classes in a background thread to avoid freezing UI
        self._initialize_backend_thread = threading.Thread(target=self._initialize_backend)
        self._initialize_backend_thread.daemon = True
        self._initialize_backend_thread.start()
        
        # Initialize UI components
        self.init_components()
        
        # Configure protocol for window close
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        
        # Show the window once it's ready
        self.deiconify()
        
        # Schedule loading progress after UI initialization
        self.after(100, self._schedule_loading_progress)
        
    def _setup_exception_handling(self):
        """Set up global exception handling to prevent crashes."""
        def handle_exception(exc_type, exc_value, exc_traceback):
            # Log the exception
            logger.error("Unhandled exception", exc_info=(exc_type, exc_value, exc_traceback))
            
            # Show a dialog to the user if it's a critical error
            if self.winfo_exists():
                error_msg = f"{exc_type.__name__}: {exc_value}"
                self.after(0, lambda: messagebox.showerror("Error", 
                    f"An unexpected error occurred:\n{error_msg}\n\nSee log for details."))
        
        # Set the exception hook
        sys.excepthook = handle_exception
    
    def _initialize_backend(self):
        """Initialize backend components in a background thread."""
        try:
            # Initialize Bitcoin wallet utility
            self.bitcoin_wallet = BitcoinWallet()
            
            # Initialize GPU accelerator
            self.gpu_accelerator = GPUAccelerator()
            
            # Initialize logger
            self.logger = BruteForceLogger(log_dir=os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "logs"))
            
            # Detect GPU
            self.gpu_info = self.gpu_accelerator.detect_gpu()
            self.gpu_available = bool(self.gpu_info)
            
            # Schedule UI update on main thread
            self.after(0, self._update_ui_after_initialization)
            
        except Exception as e:
            logger.error(f"Error initializing backend: {str(e)}")
            self.after(0, lambda: self.update_status(f"Error initializing: {str(e)}"))
    
    def _update_ui_after_initialization(self):
        """Update UI components with backend information."""
        # Update GPU information display
        self.update_gpu_info()
        
        # Load previous progress
        self.load_progress()
        
        # Update status
        if self.gpu_available:
            name = self.gpu_info.get('name', 'Unknown GPU')
            self.update_status(f"Ready - Using GPU: {name}")
            logger.info(f"GPU detected: {name}")
        else:
            self.update_status("Ready - CPU mode (no GPU detected)")
            logger.info("No GPU detected, using CPU mode")
    
    def _schedule_loading_progress(self):
        """Schedule loading of progress after UI is ready."""
        # Wait for backend initialization to complete
        if self._initialize_backend_thread.is_alive():
            self.update_status("Initializing backend components...")
            self.after(100, self._schedule_loading_progress)
        else:
            # Backend initialization is complete
            self.update_status("Ready")
    
    def update_gpu_info(self):
        """Update GPU information display."""
        # Get GPU info from accelerator
        gpu_info = self.gpu_accelerator.detect_gpu()
        
        # Update GPU tab with information
        self.gpu_tab.update_gpu_info(gpu_info)
        
        # Update sidebar with GPU status
        if gpu_info:
            name = gpu_info.get('name', 'Unknown GPU')
            self.sidebar.update_gpu_status(True, name)
            self.gpu_available = True
            logger.info(f"GPU detected: {name}")
        else:
            self.sidebar.update_gpu_status(False, "No GPU detected")
            self.gpu_available = False
            logger.info("No GPU detected, using CPU mode")
    
    def init_components(self):
        """Initialize GUI components and layout."""
        # Configure main grid layout
        self.grid_columnconfigure(0, weight=0)  # Sidebar column (fixed width)
        self.grid_columnconfigure(1, weight=1)  # Content column (expandable)
        self.grid_rowconfigure(0, weight=1)     # Main row (expandable)
        
        # Create header frame
        self.create_header()
        
        # Create sidebar with modern design
        self.sidebar = SidebarFrame(self)
        self.sidebar.grid(row=0, column=0, sticky="nsew", padx=0, pady=0)
        
        # Connect sidebar signals
        self.sidebar.on_start = self.start_brute_force
        self.sidebar.on_stop = self.stop_brute_force
        self.sidebar.on_load_addresses = self.load_target_addresses
        self.sidebar.on_export_results = self.export_results
        
        # Create main content frame
        self.content_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.content_frame.grid(row=0, column=1, sticky="nsew", padx=0, pady=0)
        self.content_frame.grid_columnconfigure(0, weight=1)
        self.content_frame.grid_rowconfigure(0, weight=1)
        self.content_frame.grid_rowconfigure(1, weight=0)
        
        # Create dashboard
        self.dashboard = DashboardFrame(self.content_frame)
        self.dashboard.grid(row=0, column=0, sticky="nsew", padx=15, pady=15)
        
        # Create tab view
        self.tab_view = ctk.CTkTabview(self.content_frame, corner_radius=10)
        self.tab_view.grid(row=1, column=0, sticky="ew", padx=15, pady=(0, 15))
        
        # Add GPU tab
        self.gpu_tab = GPUTabFrame(self.tab_view.add("GPU"))
        
        # Add Results tab
        self.results_tab = ResultsTabFrame(self.tab_view.add("Results"))
        
        # Add Logs tab
        logs_tab = self.tab_view.add("Logs")
        self.log_text = ctk.CTkTextbox(logs_tab, height=200)
        self.log_text.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Create status bar
        self.create_status_bar()
    
    def create_header(self):
        """Create application header."""
        self.header_frame = ctk.CTkFrame(self, height=60, corner_radius=0)
        self.header_frame.grid(row=0, column=0, columnspan=2, sticky="ew")
        self.header_frame.grid_propagate(False)
        
        # Add logo and title
        logo_label = ctk.CTkLabel(
            self.header_frame, 
            text="SMORE", 
            font=ctk.CTkFont(size=24, weight="bold"),
            text_color="#FF6B35"
        )
        logo_label.pack(side="left", padx=20)
        
        subtitle_label = ctk.CTkLabel(
            self.header_frame, 
            text="Bitcoin Wallet Brute-Force Tool", 
            font=ctk.CTkFont(size=14),
            text_color="#AAAAAA"
        )
        subtitle_label.pack(side="left", padx=5)
        
        # Add help and settings buttons
        help_button = ctk.CTkButton(
            self.header_frame,
            text="Help",
            width=80,
            command=self.show_help
        )
        help_button.pack(side="right", padx=10)
        
        settings_button = ctk.CTkButton(
            self.header_frame,
            text="Settings",
            width=80,
            command=self.show_settings
        )
        settings_button.pack(side="right", padx=10)
    
    def create_status_bar(self):
        """Create status bar at the bottom of the window."""
        self.status_bar = ctk.CTkFrame(self, height=25, corner_radius=0)
        self.status_bar.grid(row=1, column=0, columnspan=2, sticky="ew")
        
        self.status_label = ctk.CTkLabel(self.status_bar, text="Ready")
        self.status_label.pack(side="left", padx=10)
        
        # Add version info
        version_label = ctk.CTkLabel(self.status_bar, text="v1.0.0")
        version_label.pack(side="right", padx=10)
    
    def update_status(self, message: str) -> None:
        """Update the status bar with a message."""
        self.status_label.configure(text=message)
        
    def update_log(self, message: str) -> None:
        """Append message to log text widget."""
        self.log_text.insert("end", f"{message}\n")
        self.log_text.see("end")  # Scroll to bottom
    
    def load_target_addresses(self, file_path: Optional[str] = None) -> None:
        """Load target addresses from a file or manual input, with improved handling for large files."""
        if not file_path:
            # Ask user for file
            file_path = filedialog.askopenfilename(
                title="Select address list file",
                filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
            )
            
            if not file_path:
                return
        
        # Show a progress dialog for large files
        progress_window = None
        
        try:
            # First check file size to determine if we need a progress dialog
            file_size = os.path.getsize(file_path)
            
            # For large files (>1MB), show a progress dialog
            if file_size > 1024 * 1024:
                progress_window = ctk.CTkToplevel(self)
                progress_window.title("Loading Addresses")
                progress_window.geometry("300x150")
                progress_window.transient(self)
                progress_window.grab_set()
                
                ctk.CTkLabel(
                    progress_window, 
                    text="Loading target addresses...",
                    font=ctk.CTkFont(size=14, weight="bold")
                ).pack(pady=(20, 10))
                
                progress_bar = ctk.CTkProgressBar(progress_window)
                progress_bar.pack(padx=20, pady=10, fill="x")
                progress_bar.set(0)
                
                status_label = ctk.CTkLabel(progress_window, text="0 addresses loaded")
                status_label.pack(pady=10)
                
                # Process in a separate thread
                addresses = set()
                
                def process_file():
                    nonlocal addresses
                    count = 0
                    total_lines = sum(1 for _ in open(file_path, 'r'))
                    
                    with open(file_path, 'r') as file:
                        for line in file:
                            if line.strip():
                                addresses.add(line.strip())
                                count += 1
                                
                                # Update progress every 1000 lines
                                if count % 1000 == 0:
                                    progress = count / total_lines
                                    self.after(0, lambda p=progress, c=count: (
                                        progress_bar.set(p),
                                        status_label.configure(text=f"{c} addresses loaded")
                                    ))
                    
                    # Update UI on completion
                    self.after(0, lambda: self._finalize_address_loading(addresses, progress_window, file_path))
                
                thread = threading.Thread(target=process_file)
                thread.daemon = True
                thread.start()
                
                return  # Return early, the thread will finish loading
            
            # For smaller files, load directly
            with open(file_path, 'r') as file:
                addresses = set(line.strip() for line in file if line.strip())
            
            # Update target addresses
            self._finalize_address_loading(addresses, None, file_path)
            
        except Exception as e:
            if progress_window:
                progress_window.destroy()
            
            logger.error(f"Error loading addresses: {str(e)}")
            messagebox.showerror("Error", f"Failed to load addresses: {str(e)}")
    
    def _finalize_address_loading(self, addresses: Set[str], progress_window: Optional[ctk.CTkToplevel], file_path: str) -> None:
        """Finalize address loading after processing is complete."""
        # Update target addresses
        self.target_addresses = addresses
        
        # Update UI
        self.sidebar.update_address_count(len(addresses))
        self.update_status(f"Loaded {len(addresses)} target addresses")
        self.update_log(f"Loaded {len(addresses)} target addresses from {file_path}")
        
        # Close progress window if it exists
        if progress_window:
            progress_window.destroy()
    
    def start_brute_force(self) -> None:
        """Start the brute force process."""
        if self.running:
            return
        
        # Get parameters from sidebar
        start_key = self.sidebar.get_start_key()
        use_p2wpkh = self.sidebar.get_address_format() == "P2WPKH"
        min_balance = self.sidebar.get_min_balance()
        
        # Get all attack settings
        attack_settings = self.sidebar.get_attack_settings()
        
        # Check if we have target addresses
        if not self.target_addresses and not self.sidebar.get_target_addresses():
            messagebox.showwarning("Warning", "No target addresses specified")
            return
        
        # If manual addresses were entered in the sidebar
        if self.sidebar.get_target_addresses():
            manual_addresses = set(addr.strip() for addr in self.sidebar.get_target_addresses().split('\n') if addr.strip())
            self.target_addresses.update(manual_addresses)
            self.sidebar.update_address_count(len(self.target_addresses))
            
        # Sample address if none provided (for demo purposes)
        if not self.target_addresses:
            # For testing, add a random address that will never match
            self.target_addresses = {"1BitcoinEaterAddressDontSendf59kuE"}
            self.update_log("No target addresses provided. Using demo address for testing.")
        
        # Set the current key and reset matches
        self.current_key = start_key
        self.current_address = ""
        
        # Reset the stop event
        self.stop_event.clear()
        
        # Show appropriate message for the selected attack mode
        attack_mode = attack_settings.get("attack_mode", "Default")
        attack_mode_messages = {
            "Default": f"Starting standard brute force attack with {len(self.target_addresses)} target addresses",
            "Puzzle": f"Starting Bitcoin puzzle challenge (level {attack_settings.get('puzzle_level', 30)})",
            "Pattern": f"Starting pattern search for '{attack_settings.get('pattern_text', '')}' ({attack_settings.get('pattern_type', 'prefix')})",
            "Range": f"Starting range attack from {start_key} to {attack_settings.get('end_key', start_key + 1000000)}"
        }
        
        attack_message = attack_mode_messages.get(attack_mode, "Starting brute force attack")
        self.update_log(attack_message)
        
        # Start the brute force process
        self.gpu_accelerator.start_brute_force(
            start_key=start_key,
            target_addresses=self.target_addresses,
            use_p2wpkh=use_p2wpkh,
            callback=self.on_match_found,
            stop_event=self.stop_event,
            save_progress=self.save_progress,
            attack_settings=attack_settings
        )
        
        # Update UI
        self.running = True
        self.sidebar.set_running(True)
        self.update_status(f"Running {attack_mode} brute force attack with GPU acceleration...")
        
        # Start update thread (will update UI with latest info)
        self.update_thread = threading.Thread(target=self.update_loop)
        self.update_thread.daemon = True
        self.update_thread.start()
    
    def stop_brute_force(self) -> None:
        """Stop the brute force process."""
        if not self.running:
            return
        
        # Signal the GPU accelerator to stop
        self.stop_event.set()
        self.gpu_accelerator.stop_brute_force()
        
        # Update UI
        self.running = False
        self.sidebar.set_running(False)
        self.update_status("Brute force attack stopped")
        self.update_log("Stopped brute force attack")
        
        # Save progress
        self.save_progress(self.current_key, self.keys_per_second)
    
    def update_loop(self) -> None:
        """Background thread to update the UI with current progress."""
        update_interval = 0.2  # Update 5 times per second for smoother UI
        log_interval = 5.0  # Log stats every 5 seconds
        last_log_time = time.time()
        last_update_time = time.time()
        
        try:
            while self.running and not self.stop_event.is_set():
                current_time = time.time()
                
                # Get current values from GPU accelerator
                current_key = self.gpu_accelerator.current_key
                current_address = self.gpu_accelerator.current_address
                keys_per_second = self.gpu_accelerator.keys_per_second
                
                # Determine if it's time to update UI
                time_since_update = current_time - last_update_time
                if time_since_update >= update_interval:
                    # Use after() to schedule UI updates on the main thread
                    self.after(0, lambda ck=current_key, ca=current_address, kps=keys_per_second: self.dashboard.update_stats(
                        current_key=ck,
                        current_address=ca,
                        keys_per_second=kps,
                        matches_found=len(self.matches),
                        total_balance=self.total_balance
                    ))
                    last_update_time = current_time
                
                # Log performance stats periodically to reduce I/O overhead
                if current_time - last_log_time >= log_interval:
                    self.logger.log_performance(
                        current_key=current_key,
                        attempts=int(keys_per_second * log_interval),
                        elapsed_time=log_interval,
                        keys_per_second=keys_per_second
                    )
                    last_log_time = current_time
                
                # Sleep to prevent high CPU usage, but use adaptive sleeping
                # Shorter sleep for higher update frequency, longer when not much is happening
                if keys_per_second > 1000000:  # Very high performance
                    sleep_time = 0.05  # More frequent updates
                else:
                    sleep_time = 0.1  # Standard update rate
                    
                time.sleep(sleep_time)
                
        except Exception as e:
            # Log exceptions in the update loop but don't crash
            logger.error(f"Error in update loop: {str(e)}")
            self.after(0, lambda: self.update_status(f"Error: {str(e)}"))
        finally:
            # Ensure we update the UI with final stats even if the loop exits
            if self.running:
                self.after(0, lambda: self.dashboard.update_stats(
                    current_key=self.gpu_accelerator.current_key,
                    current_address=self.gpu_accelerator.current_address,
                    keys_per_second=self.gpu_accelerator.keys_per_second,
                    matches_found=len(self.matches),
                    total_balance=self.total_balance
                ))
    
    def on_match_found(self, wallet_data: Dict[str, str]) -> None:
        """
        Callback when a match is found.
        Processes the match in a separate thread to avoid blocking the UI.
        """
        # Process the match in a separate thread
        thread = threading.Thread(target=self._process_match, args=(wallet_data,))
        thread.daemon = True
        thread.start()
        
    def _process_match(self, wallet_data: Dict[str, str]) -> None:
        """Process a match in a background thread to avoid blocking the UI."""
        try:
            # Check balance if threshold is set
            min_balance = self.sidebar.get_min_balance()
            balance_data = None
            
            if min_balance > 0:
                address = wallet_data['p2wpkh_address'] if self.sidebar.get_address_format() == "P2WPKH" else wallet_data['p2pkh_address']
                
                # Update UI to show we're checking balance
                self.after(0, lambda addr=address: self.update_status(f"Checking balance for match: {addr}"))
                
                # Check balance (this makes API calls and might be slow)
                try:
                    # Add timeout to prevent API calls from hanging indefinitely
                    balance_data = BitcoinWallet.check_address_balance(address, timeout=5.0)
                except Exception as e:
                    logger.warning(f"Error checking balance for {address}: {str(e)}")
                    # Create empty balance data to continue processing
                    balance_data = {'balance_btc': 0.0, 'balance_usd': 0.0}
                
                # Skip if balance is below threshold
                if balance_data.get('balance_btc', 0) < min_balance:
                    self.after(0, lambda addr=address: self.update_status(f"Match found for {addr} but balance below threshold"))
                    return
            
            # Log the match
            self.logger.log_match(wallet_data, balance_data)
            
            # Add to matches list (thread-safe way)
            match_data = {
                'wallet_data': wallet_data,
                'balance_data': balance_data
            }
            
            # Use after() to safely update UI from a background thread
            self.after(0, lambda m=match_data: self._update_ui_with_match(m))
            
        except Exception as e:
            logger.error(f"Error processing match: {str(e)}")
            self.after(0, lambda err=str(e): self.update_status(f"Error processing match: {err}"))
            
    def _update_ui_with_match(self, match_data: Dict[str, Any]) -> None:
        """Update UI with match data on the main thread."""
        wallet_data = match_data['wallet_data']
        balance_data = match_data['balance_data']
        
        # Add to matches list
        self.matches.append(match_data)
        
        # Update total balance
        if balance_data:
            self.total_balance += balance_data.get('balance_btc', 0)
        
        # Update results tab
        self.results_tab.add_result(wallet_data, balance_data)
        
        # Update UI with found match
        address = wallet_data['p2pkh_address']
        hex_key = wallet_data['private_key_hex']
        self.update_log(f"Match found! Address: {address}, Private Key: {hex_key[:16]}...")
        self.update_status(f"Match found for {address}")
        
        # Show notification without blocking UI
        self.bell()  # Sound notification
        
        # Use after to show dialog after a brief delay to allow UI to update
        self.after(100, lambda: messagebox.showinfo("Match Found", f"Match found for address {address}"))
    
    def save_progress(self, current_key: int, keys_per_second: float) -> None:
        """Save current progress for later resuming."""
        self.current_key = current_key
        self.keys_per_second = keys_per_second
        
        # Update dashboard
        if self.running:
            self.dashboard.update_stats(
                current_key=current_key,
                current_address=self.current_address,
                keys_per_second=keys_per_second,
                matches_found=len(self.matches),
                total_balance=self.total_balance
            )
        
        # Get attack settings for saving
        attack_settings = {}
        if hasattr(self, 'sidebar') and self.sidebar:
            attack_settings = self.sidebar.get_attack_settings()
        
        # Save to logger with attack settings
        self.logger.save_progress(
            current_key=current_key,
            total_attempts=self.logger.total_attempts + int(keys_per_second * 2),  # Rough estimate of attempts since last save
            attack_settings=attack_settings
        )
    
    def load_progress(self) -> None:
        """Load progress from previous run."""
        progress_data = self.logger.load_progress()
        
        if progress_data:
            self.current_key = progress_data.get('current_key', 1)
            self.keys_per_second = progress_data.get('keys_per_second', 0)
            
            # Update sidebar with saved values
            self.sidebar.set_start_key(self.current_key)
            self.sidebar.set_address_format(progress_data.get('address_format', 'P2PKH'))
            self.sidebar.set_min_balance(progress_data.get('min_balance_threshold', 0.0))
            
            # Load attack settings if available
            if 'attack_settings' in progress_data and hasattr(self, 'sidebar') and self.sidebar:
                attack_settings = progress_data.get('attack_settings', {})
                
                # Set attack mode if available
                if 'attack_mode' in attack_settings:
                    self.sidebar.attack_mode_var.set(attack_settings.get('attack_mode', 'Default'))
                    self.sidebar._update_mode_options()
                
                # Set batch size if available
                if 'batch_size' in attack_settings:
                    batch_size = attack_settings.get('batch_size', 0)
                    if batch_size <= 0:
                        self.sidebar.batch_size_var.set('auto')
                    elif batch_size <= 256:
                        self.sidebar.batch_size_var.set('small')
                    elif batch_size <= 1024:
                        self.sidebar.batch_size_var.set('medium')
                    elif batch_size <= 4096:
                        self.sidebar.batch_size_var.set('large')
                    else:
                        self.sidebar.batch_size_var.set('custom')
                        self.sidebar.custom_batch_entry.delete(0, 'end')
                        self.sidebar.custom_batch_entry.insert(0, str(batch_size))
                    
                    # Update batch options UI
                    self.sidebar._update_batch_options()
                
                # Set pattern-specific settings
                if attack_settings.get('attack_mode') == 'Pattern':
                    if 'pattern_type' in attack_settings:
                        self.sidebar.pattern_var.set(attack_settings.get('pattern_type', 'prefix'))
                    if 'pattern_text' in attack_settings:
                        self.sidebar.pattern_text_entry.delete(0, 'end')
                        self.sidebar.pattern_text_entry.insert(0, attack_settings.get('pattern_text', '1'))
                
                # Set puzzle-specific settings
                elif attack_settings.get('attack_mode') == 'Puzzle':
                    if 'puzzle_level' in attack_settings:
                        self.sidebar.puzzle_level_var.set(attack_settings.get('puzzle_level', 30))
                        self.sidebar._update_puzzle_level_display()
                
                # Set range-specific settings
                elif attack_settings.get('attack_mode') == 'Range':
                    if 'end_key' in attack_settings:
                        self.sidebar.range_end_entry.delete(0, 'end')
                        self.sidebar.range_end_entry.insert(0, str(attack_settings.get('end_key', 1000000)))
                    if 'range_chunks' in attack_settings:
                        self.sidebar.range_chunks_var.set(attack_settings.get('range_chunks', 4))
                        self.sidebar._update_range_chunks_display()
            
            # Load target addresses if available
            if 'target_addresses' in progress_data:
                self.target_addresses = set(progress_data['target_addresses'])
                self.sidebar.update_address_count(len(self.target_addresses))
            
            # Update log
            self.update_log(f"Loaded previous progress: Current key = {self.current_key}")
    
    def export_results(self) -> None:
        """Export results to a file with progress indication for large result sets."""
        if not self.matches and not os.path.exists(self.logger.matches_log_path):
            messagebox.showinfo("No Results", "No matches found to export")
            return
        
        # Ask for export file path
        file_path = filedialog.asksaveasfilename(
            title="Export Results",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("CSV files", "*.csv"), ("JSON files", "*.json"), ("All files", "*.*")]
        )
        
        if not file_path:
            return
            
        # Progress dialog for export process
        progress_window = ctk.CTkToplevel(self)
        progress_window.title("Exporting Results")
        progress_window.geometry("300x150")
        progress_window.transient(self)
        progress_window.grab_set()
        
        # Setup progress UI
        ctk.CTkLabel(
            progress_window, 
            text="Exporting results...",
            font=ctk.CTkFont(size=14, weight="bold")
        ).pack(pady=(20, 10))
        
        progress_bar = ctk.CTkProgressBar(progress_window)
        progress_bar.pack(padx=20, pady=10, fill="x")
        progress_bar.set(0)
        
        status_label = ctk.CTkLabel(progress_window, text="Preparing export...")
        status_label.pack(pady=10)
        
        # Use a background thread for exporting
        def export_task():
            success = False
            error_msg = ""
            
            try:
                # Export matches in background thread (using BruteForceLogger)
                success = self.logger.export_results(file_path)
                
                # Schedule UI update to main thread
                if success:
                    self.after(0, lambda: progress_bar.set(1.0))
                    self.after(0, lambda: status_label.configure(text=f"Export complete: {file_path}"))
                    time.sleep(1)  # Brief pause to show completion
                else:
                    error_msg = "Export failed (file write error)"
            except Exception as e:
                error_msg = str(e)
                logger.error(f"Error exporting results: {error_msg}")
            finally:
                # Close dialog and update UI on main thread
                self.after(0, lambda: self._finish_export(progress_window, success, error_msg, file_path))
        
        # Start export thread
        export_thread = threading.Thread(target=export_task)
        export_thread.daemon = True
        export_thread.start()
    
    def _finish_export(self, 
                       progress_window: ctk.CTkToplevel, 
                       success: bool, 
                       error_msg: str, 
                       file_path: str) -> None:
        """Finalize export process after background thread completes."""
        # Close progress window
        progress_window.destroy()
        
        # Show appropriate message
        if success:
            messagebox.showinfo("Export Successful", f"Results exported to {file_path}")
            self.update_log(f"Exported results to {file_path}")
        else:
            error_text = f"Failed to export results: {error_msg}" if error_msg else "Failed to export results"
            messagebox.showerror("Export Failed", error_text)
    
    def show_help(self):
        """Show help documentation."""
        try:
            webbrowser.open("https://github.com/yourusername/smore#readme")
        except Exception:
            # If browser fails, show help in a dialog
            help_text = """
Smore: Bitcoin Wallet Brute-force Tool

Usage Instructions:
1. Load target addresses from a file or enter them manually
2. Set a starting key (or use the default)
3. Select address format (P2PKH or P2WPKH)
4. Set minimum balance threshold if desired
5. Click Start to begin the brute force process

For more information, visit the GitHub repository.
"""
            messagebox.showinfo("Help", help_text)
    
    def show_settings(self):
        """Show settings dialog."""
        settings_window = ctk.CTkToplevel(self)
        settings_window.title("Settings")
        settings_window.geometry("500x400")
        settings_window.resizable(False, False)
        settings_window.grab_set()
        
        # Create settings UI
        ctk.CTkLabel(
            settings_window, 
            text="Application Settings", 
            font=ctk.CTkFont(size=20, weight="bold")
        ).pack(pady=20)
        
        # Performance settings
        perf_frame = ctk.CTkFrame(settings_window)
        perf_frame.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(
            perf_frame,
            text="Performance Settings",
            font=ctk.CTkFont(size=16, weight="bold")
        ).pack(anchor="w", padx=10, pady=5)
        
        # Always use GPU (disabled, since it's forced)
        gpu_var = tk.BooleanVar(value=True)
        gpu_checkbox = ctk.CTkCheckBox(
            perf_frame,
            text="Force GPU Mode (Always Enabled)",
            variable=gpu_var,
            state="disabled"
        )
        gpu_checkbox.pack(anchor="w", padx=20, pady=5)
        
        # Save/Cancel buttons
        button_frame = ctk.CTkFrame(settings_window, fg_color="transparent")
        button_frame.pack(fill="x", padx=20, pady=20)
        
        ctk.CTkButton(
            button_frame,
            text="Save",
            width=100,
            command=settings_window.destroy
        ).pack(side="right", padx=5)
        
        ctk.CTkButton(
            button_frame,
            text="Cancel",
            width=100,
            command=settings_window.destroy
        ).pack(side="right", padx=5)
    
    def on_close(self) -> None:
        """Handle window close event."""
        if self.running:
            if messagebox.askyesno("Quit", "Brute force is still running. Do you want to stop and quit?"):
                self.stop_brute_force()
                self.destroy()
        else:
            self.destroy() 