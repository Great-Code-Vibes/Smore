import customtkinter as ctk
from typing import Callable, Optional, Any
import os

class SidebarFrame(ctk.CTkFrame):
    """
    Sidebar frame for user input controls and settings with a modern design.
    """
    def __init__(self, master, **kwargs):
        kwargs["width"] = 300
        kwargs["corner_radius"] = 0
        super().__init__(master, **kwargs)
        
        # Configure grid
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(4, weight=1)  # Make the bottom section expandable
        
        # Create sections with modern UI
        self.create_target_address_section()
        self.create_key_range_section()
        self.create_options_section()
        self.create_control_buttons()
        
        # Callback handlers
        self.on_start = None
        self.on_stop = None
        self.on_load_addresses = None
        self.on_export_results = None
    
    def create_target_address_section(self) -> None:
        """Create the target address section of the sidebar."""
        # Target address frame
        self.address_frame = ctk.CTkFrame(self)
        self.address_frame.grid(row=0, column=0, padx=20, pady=10, sticky="ew")
        
        # Label with icon
        target_label = ctk.CTkLabel(
            self.address_frame, 
            text="📁 Target Addresses", 
            font=ctk.CTkFont(size=16, weight="bold")
        )
        target_label.grid(row=0, column=0, padx=10, pady=(10, 5), sticky="w")
        
        # Address count label
        self.address_count_label = ctk.CTkLabel(
            self.address_frame, 
            text="0 addresses loaded", 
            font=ctk.CTkFont(size=12)
        )
        self.address_count_label.grid(row=1, column=0, padx=10, pady=(0, 5), sticky="w")
        
        # Load addresses button with modern design
        self.load_addresses_button = ctk.CTkButton(
            self.address_frame, 
            text="Load Address File",
            command=self._on_load_addresses_click,
            corner_radius=6,
            height=32
        )
        self.load_addresses_button.grid(row=2, column=0, padx=10, pady=5, sticky="ew")
        
        # Manual address entry with better styling
        manual_label = ctk.CTkLabel(
            self.address_frame, 
            text="Or enter addresses manually (one per line):", 
            font=ctk.CTkFont(size=12)
        )
        manual_label.grid(row=3, column=0, padx=10, pady=(10, 5), sticky="w")
        
        self.address_text = ctk.CTkTextbox(self.address_frame, height=100, corner_radius=6)
        self.address_text.grid(row=4, column=0, padx=10, pady=(0, 10), sticky="ew")
    
    def create_key_range_section(self) -> None:
        """Create the key range section of the sidebar."""
        # Key range frame
        self.key_range_frame = ctk.CTkFrame(self)
        self.key_range_frame.grid(row=1, column=0, padx=20, pady=10, sticky="ew")
        
        # Label with icon
        range_label = ctk.CTkLabel(
            self.key_range_frame, 
            text="🔎 Key Range", 
            font=ctk.CTkFont(size=16, weight="bold")
        )
        range_label.grid(row=0, column=0, padx=10, pady=(10, 5), sticky="w")
        
        # Start key with better layout
        start_label = ctk.CTkLabel(
            self.key_range_frame, 
            text="Start Private Key (int):", 
            font=ctk.CTkFont(size=12)
        )
        start_label.grid(row=1, column=0, padx=10, pady=(10, 0), sticky="w")
        
        self.start_key_entry = ctk.CTkEntry(self.key_range_frame, corner_radius=6, height=32)
        self.start_key_entry.grid(row=2, column=0, padx=10, pady=(0, 5), sticky="ew")
        self.start_key_entry.insert(0, "1")  # Default to 1
        
        # Info label with clearer text
        info_label = ctk.CTkLabel(
            self.key_range_frame, 
            text="Valid range: 1 to 2^256 - 1", 
            font=ctk.CTkFont(size=10),
            text_color="#888888"
        )
        info_label.grid(row=3, column=0, padx=10, pady=(0, 10), sticky="w")
    
    def create_options_section(self) -> None:
        """Create the options section of the sidebar."""
        # Options frame
        self.options_frame = ctk.CTkFrame(self)
        self.options_frame.grid(row=2, column=0, padx=20, pady=10, sticky="ew")
        
        # Label with icon
        options_label = ctk.CTkLabel(
            self.options_frame, 
            text="⚙️ Options", 
            font=ctk.CTkFont(size=16, weight="bold")
        )
        options_label.grid(row=0, column=0, padx=10, pady=(10, 5), sticky="w")
        
        # Attack mode section
        attack_mode_label = ctk.CTkLabel(
            self.options_frame, 
            text="🎯 Attack Mode:", 
            font=ctk.CTkFont(size=13, weight="bold")
        )
        attack_mode_label.grid(row=1, column=0, padx=10, pady=(10, 0), sticky="w")
        
        self.attack_mode_var = ctk.StringVar(value="Default")
        
        attack_modes = [
            ("Default (All Keys)", "Default"),
            ("BTC Puzzle Challenge", "Puzzle"),
            ("Pattern Search", "Pattern"),
            ("Range Splitting", "Range")
        ]
        
        for i, (text, value) in enumerate(attack_modes):
            mode_radio = ctk.CTkRadioButton(
                self.options_frame,
                text=text,
                variable=self.attack_mode_var,
                value=value,
                command=self._update_mode_options
            )
            mode_radio.grid(row=2+i, column=0, padx=20, pady=(5, 0), sticky="w")
        
        # Puzzle challenge config (initially hidden)
        self.puzzle_frame = ctk.CTkFrame(self.options_frame, fg_color="transparent")
        self.puzzle_frame.grid(row=6, column=0, padx=10, pady=(5, 0), sticky="ew")
        self.puzzle_frame.grid_remove()  # Hide initially
        
        puzzle_level_label = ctk.CTkLabel(
            self.puzzle_frame,
            text="Puzzle Level (0-100):"
        )
        puzzle_level_label.grid(row=0, column=0, padx=10, pady=(5, 0), sticky="w")
        
        self.puzzle_level_var = ctk.IntVar(value=30)
        self.puzzle_level_slider = ctk.CTkSlider(
            self.puzzle_frame,
            from_=0,
            to=100,
            variable=self.puzzle_level_var
        )
        self.puzzle_level_slider.grid(row=1, column=0, padx=10, pady=(5, 0), sticky="ew")
        
        self.puzzle_level_display = ctk.CTkLabel(
            self.puzzle_frame,
            text="Level 30"
        )
        self.puzzle_level_display.grid(row=1, column=1, padx=5, pady=(5, 0), sticky="w")
        
        # Connect slider to label update
        self.puzzle_level_slider.configure(command=self._update_puzzle_level_display)
        
        # Pattern search options (initially hidden)
        self.pattern_frame = ctk.CTkFrame(self.options_frame, fg_color="transparent")
        self.pattern_frame.grid(row=7, column=0, padx=10, pady=(5, 0), sticky="ew")
        self.pattern_frame.grid_remove()  # Hide initially
        
        pattern_label = ctk.CTkLabel(
            self.pattern_frame,
            text="Search Pattern:"
        )
        pattern_label.grid(row=0, column=0, padx=10, pady=(5, 0), sticky="w")
        
        self.pattern_var = ctk.StringVar(value="prefix")
        patterns = [
            ("Address Prefix", "prefix"),
            ("Address Suffix", "suffix"),
            ("Vanity Pattern", "vanity"),
            ("Repeated Chars", "repeat")
        ]
        
        for i, (text, value) in enumerate(patterns):
            pattern_radio = ctk.CTkRadioButton(
                self.pattern_frame,
                text=text,
                variable=self.pattern_var,
                value=value
            )
            pattern_radio.grid(row=1+i, column=0, padx=20, pady=(5, 0), sticky="w")
        
        pattern_text_label = ctk.CTkLabel(
            self.pattern_frame,
            text="Pattern Text:"
        )
        pattern_text_label.grid(row=5, column=0, padx=10, pady=(5, 0), sticky="w")
        
        self.pattern_text_entry = ctk.CTkEntry(self.pattern_frame, corner_radius=6)
        self.pattern_text_entry.grid(row=6, column=0, padx=10, pady=(5, 10), sticky="ew")
        self.pattern_text_entry.insert(0, "1")  # Default pattern
        
        # Range splitting options (initially hidden)
        self.range_frame = ctk.CTkFrame(self.options_frame, fg_color="transparent")
        self.range_frame.grid(row=8, column=0, padx=10, pady=(5, 0), sticky="ew")
        self.range_frame.grid_remove()  # Hide initially
        
        range_end_label = ctk.CTkLabel(
            self.range_frame,
            text="End Key (int):"
        )
        range_end_label.grid(row=0, column=0, padx=10, pady=(5, 0), sticky="w")
        
        self.range_end_entry = ctk.CTkEntry(self.range_frame, corner_radius=6)
        self.range_end_entry.grid(row=1, column=0, padx=10, pady=(5, 0), sticky="ew")
        self.range_end_entry.insert(0, "1000000")  # Default end
        
        range_chunks_label = ctk.CTkLabel(
            self.range_frame,
            text="Split into chunks:"
        )
        range_chunks_label.grid(row=2, column=0, padx=10, pady=(5, 0), sticky="w")
        
        self.range_chunks_var = ctk.IntVar(value=4)
        range_chunks_slider = ctk.CTkSlider(
            self.range_frame,
            from_=1,
            to=16,
            number_of_steps=15,
            variable=self.range_chunks_var
        )
        range_chunks_slider.grid(row=3, column=0, padx=10, pady=(5, 0), sticky="ew")
        
        self.range_chunks_display = ctk.CTkLabel(
            self.range_frame,
            text="4 chunks"
        )
        self.range_chunks_display.grid(row=3, column=1, padx=5, pady=(5, 0), sticky="w")
        
        # Connect slider to label update
        range_chunks_slider.configure(command=self._update_range_chunks_display)
        
        # Performance optimization section
        optimization_label = ctk.CTkLabel(
            self.options_frame, 
            text="⚡ Performance:", 
            font=ctk.CTkFont(size=13, weight="bold")
        )
        optimization_label.grid(row=9, column=0, padx=10, pady=(15, 0), sticky="w")
        
        # Batch size options
        batch_size_label = ctk.CTkLabel(
            self.options_frame,
            text="Batch Size:"
        )
        batch_size_label.grid(row=10, column=0, padx=10, pady=(5, 0), sticky="w")
        
        self.batch_size_var = ctk.StringVar(value="auto")
        batch_sizes = [
            ("Auto (Recommended)", "auto"),
            ("Small (Better UI)", "small"),
            ("Medium", "medium"),
            ("Large (Better Performance)", "large"),
            ("Custom", "custom")
        ]
        
        for i, (text, value) in enumerate(batch_sizes):
            batch_radio = ctk.CTkRadioButton(
                self.options_frame,
                text=text,
                variable=self.batch_size_var,
                value=value,
                command=self._update_batch_options
            )
            batch_radio.grid(row=11+i, column=0, padx=20, pady=(5, 0), sticky="w")
        
        # Custom batch size entry (initially hidden)
        self.custom_batch_frame = ctk.CTkFrame(self.options_frame, fg_color="transparent")
        self.custom_batch_frame.grid(row=16, column=0, padx=10, pady=(5, 0), sticky="ew")
        self.custom_batch_frame.grid_remove()  # Hide initially
        
        self.custom_batch_entry = ctk.CTkEntry(self.custom_batch_frame, corner_radius=6)
        self.custom_batch_entry.pack(padx=20, pady=5, fill="x")
        self.custom_batch_entry.insert(0, "1024")  # Default batch size
        
        # Address format with clearer labels
        format_label = ctk.CTkLabel(
            self.options_frame, 
            text="🏷️ Address Format:", 
            font=ctk.CTkFont(size=13, weight="bold")
        )
        format_label.grid(row=17, column=0, padx=10, pady=(15, 0), sticky="w")
        
        self.address_format_var = ctk.StringVar(value="P2PKH")
        
        p2pkh_radio = ctk.CTkRadioButton(
            self.options_frame, 
            text="P2PKH (default, legacy)",
            variable=self.address_format_var, 
            value="P2PKH"
        )
        p2pkh_radio.grid(row=18, column=0, padx=20, pady=(5, 0), sticky="w")
        
        p2wpkh_radio = ctk.CTkRadioButton(
            self.options_frame, 
            text="P2WPKH (SegWit)",
            variable=self.address_format_var, 
            value="P2WPKH"
        )
        p2wpkh_radio.grid(row=19, column=0, padx=20, pady=(5, 0), sticky="w")
        
        # Minimum balance with better design
        balance_label = ctk.CTkLabel(
            self.options_frame, 
            text="💵 Minimum Balance (BTC):", 
            font=ctk.CTkFont(size=13, weight="bold")
        )
        balance_label.grid(row=20, column=0, padx=10, pady=(15, 0), sticky="w")
        
        self.min_balance_entry = ctk.CTkEntry(self.options_frame, corner_radius=6, height=32)
        self.min_balance_entry.grid(row=21, column=0, padx=10, pady=(5, 5), sticky="ew")
        self.min_balance_entry.insert(0, "0.001")  # Default to 0.001 BTC
        
        # GPU acceleration status
        gpu_label = ctk.CTkLabel(
            self.options_frame, 
            text="🧠 GPU Acceleration:", 
            font=ctk.CTkFont(size=13, weight="bold")
        )
        gpu_label.grid(row=22, column=0, padx=10, pady=(15, 0), sticky="w")
        
        self.gpu_status_label = ctk.CTkLabel(
            self.options_frame,
            text="Force Enabled (Maximum Performance)",
            font=ctk.CTkFont(size=12),
            text_color="#22bb33"
        )
        self.gpu_status_label.grid(row=23, column=0, padx=20, pady=(5, 10), sticky="w")
    
    def create_control_buttons(self) -> None:
        """Create control buttons section of the sidebar."""
        # Control buttons frame
        self.control_frame = ctk.CTkFrame(self)
        self.control_frame.grid(row=3, column=0, padx=20, pady=10, sticky="ew")
        
        # Start button with improved design
        self.start_button = ctk.CTkButton(
            self.control_frame, 
            text="▶️ Start",
            command=self._on_start_click,
            fg_color="#28a745",
            hover_color="#218838",
            corner_radius=6,
            height=40,
            font=ctk.CTkFont(size=14, weight="bold")
        )
        self.start_button.grid(row=0, column=0, padx=10, pady=10, sticky="ew")
        
        # Stop button with improved design
        self.stop_button = ctk.CTkButton(
            self.control_frame, 
            text="⏹ Stop",
            command=self._on_stop_click,
            fg_color="#dc3545",
            hover_color="#c82333",
            corner_radius=6,
            height=40,
            font=ctk.CTkFont(size=14, weight="bold"),
            state="disabled"
        )
        self.stop_button.grid(row=1, column=0, padx=10, pady=(0, 10), sticky="ew")
        
        # Export results button
        self.export_button = ctk.CTkButton(
            self.control_frame, 
            text="📤 Export Results",
            command=self._on_export_click,
            corner_radius=6,
            height=32
        )
        self.export_button.grid(row=2, column=0, padx=10, pady=(0, 10), sticky="ew")
        
        # Additional status section at the bottom
        self.status_frame = ctk.CTkFrame(self)
        self.status_frame.grid(row=4, column=0, padx=20, pady=10, sticky="ews")
        
        self.status_label = ctk.CTkLabel(
            self.status_frame,
            text="Ready to start brute force attack",
            font=ctk.CTkFont(size=12),
            text_color="#888888"
        )
        self.status_label.pack(pady=10)
    
    def update_address_count(self, count: int) -> None:
        """Update the address count label."""
        self.address_count_label.configure(text=f"{count} addresses loaded")
    
    def update_gpu_status(self, is_available: bool, device_name: str) -> None:
        """Update the GPU status display."""
        if is_available:
            self.gpu_status_label.configure(
                text=f"Enabled: {device_name}",
                text_color="#22bb33"
            )
        else:
            self.gpu_status_label.configure(
                text="Not available (using CPU)",
                text_color="#dc3545"
            )
    
    def get_start_key(self) -> int:
        """Get the start key from the entry."""
        try:
            return int(self.start_key_entry.get())
        except ValueError:
            return 1  # Default to 1 if invalid
    
    def set_start_key(self, key: int) -> None:
        """Set the start key entry value."""
        self.start_key_entry.delete(0, "end")
        self.start_key_entry.insert(0, str(key))
    
    def get_address_format(self) -> str:
        """Get the selected address format."""
        return self.address_format_var.get()
    
    def set_address_format(self, format_type: str) -> None:
        """Set the address format selection."""
        self.address_format_var.set(format_type)
    
    def get_min_balance(self) -> float:
        """Get the minimum balance threshold."""
        try:
            return float(self.min_balance_entry.get())
        except ValueError:
            return 0.0  # Default to 0 if invalid
    
    def set_min_balance(self, balance: float) -> None:
        """Set the minimum balance entry value."""
        self.min_balance_entry.delete(0, "end")
        self.min_balance_entry.insert(0, str(balance))
    
    def get_use_gpu(self) -> bool:
        """Get the GPU acceleration setting."""
        return True  # Always return True as GPU is forced on
    
    def get_target_addresses(self) -> str:
        """Get the manually entered target addresses."""
        return self.address_text.get("1.0", "end")
    
    def set_running(self, is_running: bool) -> None:
        """Update the UI state based on running status."""
        if is_running:
            self.start_button.configure(state="disabled")
            self.stop_button.configure(state="normal")
            self.load_addresses_button.configure(state="disabled")
            self.address_text.configure(state="disabled")
            self.start_key_entry.configure(state="disabled")
            self.status_label.configure(
                text="Brute force attack running...",
                text_color="#22bb33"
            )
        else:
            self.start_button.configure(state="normal")
            self.stop_button.configure(state="disabled")
            self.load_addresses_button.configure(state="normal")
            self.address_text.configure(state="normal")
            self.start_key_entry.configure(state="normal")
            self.status_label.configure(
                text="Ready to start brute force attack",
                text_color="#888888"
            )
    
    def _on_start_click(self) -> None:
        """Handle start button click."""
        if self.on_start:
            self.on_start()
    
    def _on_stop_click(self) -> None:
        """Handle stop button click."""
        if self.on_stop:
            self.on_stop()
    
    def _on_load_addresses_click(self) -> None:
        """Handle load addresses button click."""
        if self.on_load_addresses:
            self.on_load_addresses()
    
    def _on_export_click(self) -> None:
        """Handle export results button click."""
        if self.on_export_results:
            self.on_export_results()
    
    def _update_mode_options(self) -> None:
        """Update visible options based on selected attack mode."""
        mode = self.attack_mode_var.get()
        
        # Hide all specialized frames first
        self.puzzle_frame.grid_remove()
        self.pattern_frame.grid_remove()
        self.range_frame.grid_remove()
        
        # Show the appropriate frame based on selection
        if mode == "Puzzle":
            self.puzzle_frame.grid()
        elif mode == "Pattern":
            self.pattern_frame.grid()
        elif mode == "Range":
            self.range_frame.grid()
    
    def _update_batch_options(self) -> None:
        """Update batch size options based on selection."""
        if self.batch_size_var.get() == "custom":
            self.custom_batch_frame.grid()
        else:
            self.custom_batch_frame.grid_remove()
    
    def _update_puzzle_level_display(self, value=None) -> None:
        """Update the puzzle level display."""
        level = self.puzzle_level_var.get()
        self.puzzle_level_display.configure(text=f"Level {level}")
    
    def _update_range_chunks_display(self, value=None) -> None:
        """Update the range chunks display."""
        chunks = self.range_chunks_var.get()
        self.range_chunks_display.configure(text=f"{chunks} chunks")
    
    def get_attack_settings(self) -> dict:
        """Get all attack settings as a dictionary."""
        settings = {
            "attack_mode": self.attack_mode_var.get(),
            "address_format": self.address_format_var.get(),
            "min_balance": self.get_min_balance(),
            "start_key": self.get_start_key(),
            "batch_size": self.get_batch_size()
        }
        
        # Add mode-specific settings
        if settings["attack_mode"] == "Puzzle":
            settings["puzzle_level"] = self.puzzle_level_var.get()
        elif settings["attack_mode"] == "Pattern":
            settings["pattern_type"] = self.pattern_var.get()
            settings["pattern_text"] = self.pattern_text_entry.get()
        elif settings["attack_mode"] == "Range":
            try:
                settings["end_key"] = int(self.range_end_entry.get())
            except ValueError:
                settings["end_key"] = self.get_start_key() + 1000000
            settings["range_chunks"] = self.range_chunks_var.get()
        
        return settings
    
    def get_batch_size(self) -> int:
        """Get the batch size based on settings."""
        batch_type = self.batch_size_var.get()
        
        if batch_type == "auto":
            return 0  # Let the system decide
        elif batch_type == "small":
            return 256
        elif batch_type == "medium":
            return 1024
        elif batch_type == "large":
            return 4096
        elif batch_type == "custom":
            try:
                return max(64, int(self.custom_batch_entry.get()))
            except ValueError:
                return 1024  # Default if invalid 