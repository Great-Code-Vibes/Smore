import os
import time
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import threading
import customtkinter as ctk
from pathlib import Path

def show_splash_screen():
    root = tk.Tk()
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    
    width = 600
    height = 400
    x = (screen_width - width) // 2
    y = (screen_height - height) // 2
    
    root.geometry(f"{width}x{height}+{x}+{y}")
    
    frame = tk.Frame(root, bg="#1E1E1E", width=width, height=height)
    frame.pack(fill="both", expand=True)
    
    assets_dir = Path(__file__).parent.parent / "assets"
    logo_path = assets_dir / "logo.png"
    
    if not logo_path.exists():
        assets_dir.mkdir(exist_ok=True)
        img = Image.new('RGBA', (300, 200), color=(30, 30, 30, 0))
        img.save(logo_path)
    
    try:
        logo_img = Image.open(logo_path)
        logo_img = logo_img.resize((300, 200), Image.LANCZOS)
        logo_photo = ImageTk.PhotoImage(logo_img)
        
        logo_label = tk.Label(frame, image=logo_photo, bg="#1E1E1E")
        logo_label.image = logo_photo
        logo_label.pack(pady=(50, 20))
    except Exception:
        logo_label = tk.Label(
            frame, 
            text="SMORE", 
            font=("Arial", 36, "bold"), 
            fg="#FF6B35", 
            bg="#1E1E1E"
        )
        logo_label.pack(pady=(80, 20))
    
    title_label = tk.Label(
        frame,
        text="Bitcoin Wallet Brute-Force Tool",
        font=("Arial", 16),
        fg="#FFFFFF",
        bg="#1E1E1E"
    )
    title_label.pack(pady=(0, 30))
    
    progress_frame = tk.Frame(frame, bg="#1E1E1E", width=400, height=20)
    progress_frame.pack(pady=(0, 20))
    progress_frame.pack_propagate(False)
    
    progress = ttk.Progressbar(
        progress_frame,
        orient="horizontal",
        length=400,
        mode="indeterminate"
    )
    progress.pack(fill="both", expand=True)
    
    status_label = tk.Label(
        frame,
        text="Initializing...",
        font=("Arial", 10),
        fg="#AAAAAA",
        bg="#1E1E1E"
    )
    status_label.pack(pady=(0, 20))
    
    progress.start(15)
    
    status_messages = [
        "Detecting GPU hardware...",
        "Loading cryptographic modules...",
        "Initializing UI components...",
        "Preparing application..."
    ]
    
    def update_status():
        for message in status_messages:
            status_label.config(text=message)
            time.sleep(0.7)
        
        time.sleep(0.5)
        root.destroy()
    
    threading.Thread(target=update_status, daemon=True).start()
    
    root.mainloop()
    
    # Return None since we'll create a new window in the main app
    return None 