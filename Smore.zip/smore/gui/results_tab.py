import customtkinter as ctk
from typing import Dict, Any, Optional, List
import time
from datetime import datetime

class ResultsTabFrame(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        
        self.title_label = ctk.CTkLabel(
            self, 
            text="Match Results", 
            font=ctk.CTkFont(size=18, weight="bold")
        )
        self.title_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        self.results_frame = ctk.CTkScrollableFrame(self)
        self.results_frame.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="nsew")
        self.results_frame.grid_columnconfigure(0, weight=1)
        
        self.placeholder = ctk.CTkLabel(
            self.results_frame,
            text="No matches found yet. Results will appear here.",
            font=ctk.CTkFont(size=14),
            text_color="#888888"
        )
        self.placeholder.grid(row=0, column=0, padx=20, pady=40)
        
        self.result_cards = []
    
    def add_result(self, wallet_data: Dict[str, str], balance_data: Optional[Dict[str, Any]] = None) -> None:
        if not self.result_cards:
            self.placeholder.grid_forget()
        
        card = ctk.CTkFrame(self.results_frame, corner_radius=10)
        card.grid(row=len(self.result_cards), column=0, padx=10, pady=5, sticky="ew")
        card.grid_columnconfigure(1, weight=1)
        
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        header_frame = ctk.CTkFrame(card, fg_color="transparent")
        header_frame.grid(row=0, column=0, columnspan=2, padx=10, pady=(10, 5), sticky="ew")
        
        timestamp_label = ctk.CTkLabel(
            header_frame,
            text=f"Found: {timestamp}",
            font=ctk.CTkFont(size=12),
            text_color="#888888"
        )
        timestamp_label.pack(side="left")
        
        if balance_data and 'balance_btc' in balance_data:
            balance_text = f"Balance: {balance_data['balance_btc']:.8f} BTC"
            balance_color = "#22bb33" if balance_data['balance_btc'] > 0 else "#888888"
        else:
            balance_text = "Balance: Unknown"
            balance_color = "#888888"
        
        balance_label = ctk.CTkLabel(
            header_frame,
            text=balance_text,
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color=balance_color
        )
        balance_label.pack(side="right")
        
        self._add_card_field(card, 1, "Private Key (HEX):", wallet_data['private_key_hex'], True)
        
        self._add_card_field(card, 2, "Private Key (WIF):", wallet_data['wif'])
        
        self._add_card_field(card, 3, "Public Key:", wallet_data['public_key'])
        
        self._add_card_field(card, 4, "P2PKH Address:", wallet_data['p2pkh_address'])
        
        self._add_card_field(card, 5, "P2WPKH Address:", wallet_data['p2wpkh_address'])
        
        buttons_frame = ctk.CTkFrame(card, fg_color="transparent")
        buttons_frame.grid(row=6, column=0, columnspan=2, padx=10, pady=10, sticky="e")
        
        copy_button = ctk.CTkButton(
            buttons_frame,
            text="Copy All",
            width=80,
            command=lambda: self._copy_result_to_clipboard(wallet_data, balance_data)
        )
        copy_button.pack(side="left", padx=5)
        
        self.result_cards.append(card)
    
    def _add_card_field(self, parent, row, label_text, value_text, highlight=False):
        label = ctk.CTkLabel(
            parent,
            text=label_text,
            font=ctk.CTkFont(size=12),
            text_color="#888888"
        )
        label.grid(row=row, column=0, padx=10, pady=2, sticky="w")
        
        text_color = "#FF6B35" if highlight else "white"
        value = ctk.CTkLabel(
            parent,
            text=value_text,
            font=ctk.CTkFont(size=12, weight="bold" if highlight else "normal"),
            text_color=text_color,
            wraplength=400
        )
        value.grid(row=row, column=1, padx=10, pady=2, sticky="ew")
    
    def _copy_result_to_clipboard(self, wallet_data, balance_data):
        clipboard_text = f"""
Smore Match Result
=================
Private Key (HEX): {wallet_data['private_key_hex']}
Private Key (WIF): {wallet_data['wif']}
Public Key: {wallet_data['public_key']}
P2PKH Address: {wallet_data['p2pkh_address']}
P2WPKH Address: {wallet_data['p2wpkh_address']}
"""
        
        if balance_data:
            clipboard_text += f"Balance: {balance_data.get('balance_btc', 0):.8f} BTC\n"
        
        try:
            self.clipboard_clear()
            self.clipboard_append(clipboard_text)
            
            temp_label = ctk.CTkLabel(
                self,
                text="Copied to clipboard!",
                font=ctk.CTkFont(size=12),
                fg_color="#22bb33",
                corner_radius=5,
                text_color="white"
            )
            temp_label.place(relx=0.5, rely=0.9, anchor="center")
            
            self.after(2000, temp_label.destroy)
        except Exception as e:
            print(f"Error copying to clipboard: {e}") 