import customtkinter as ctk
from typing import Dict, Any, Optional
import sys
import platform
import webbrowser

class GPUTabFrame(ctk.CTkFrame):
    """
    Frame for displaying GPU hardware information and acceleration status.
    """
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        
        # Configure grid
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)
        
        # Create title
        self.title_label = ctk.CTkLabel(
            self, 
            text="GPU Acceleration", 
            font=ctk.CTkFont(size=18, weight="bold")
        )
        self.title_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="w")
        
        # Create informational label
        info_text = "Smore automatically leverages GPU acceleration for maximum performance."
        self.info_label = ctk.CTkLabel(
            self,
            text=info_text,
            font=ctk.CTkFont(size=12),
        )
        self.info_label.grid(row=1, column=0, padx=20, pady=(0, 15), sticky="w")
        
        # Create main content area
        self.content_frame = ctk.CTkFrame(self)
        self.content_frame.grid(row=2, column=0, padx=20, pady=(0, 20), sticky="nsew")
        self.content_frame.grid_columnconfigure(0, weight=2)
        self.content_frame.grid_columnconfigure(1, weight=3)
        
        # Create GPU information section
        self.create_gpu_section()
        
        # Create dependency section
        self.create_dependency_section()
    
    def create_gpu_section(self) -> None:
        """Create GPU information display section with modern design."""
        # GPU information frame with card-like design
        self.gpu_frame = ctk.CTkFrame(self.content_frame, corner_radius=10)
        self.gpu_frame.grid(row=0, column=0, padx=15, pady=15, sticky="nsew")
        
        # Configure frame grid
        self.gpu_frame.grid_columnconfigure(0, weight=0)
        self.gpu_frame.grid_columnconfigure(1, weight=1)
        
        # Section title
        gpu_title = ctk.CTkLabel(
            self.gpu_frame,
            text="GPU Hardware Information",
            font=ctk.CTkFont(size=16, weight="bold")
        )
        gpu_title.grid(row=0, column=0, columnspan=2, padx=15, pady=(15, 10), sticky="w")
        
        # Status label with modern styling
        status_label = ctk.CTkLabel(
            self.gpu_frame,
            text="Status:",
            font=ctk.CTkFont(size=13, weight="bold")
        )
        status_label.grid(row=1, column=0, padx=15, pady=(10, 0), sticky="w")
        
        self.gpu_status = ctk.CTkLabel(
            self.gpu_frame,
            text="Detecting...",
            font=ctk.CTkFont(size=13)
        )
        self.gpu_status.grid(row=1, column=1, padx=15, pady=(10, 0), sticky="w")
        
        # GPU name
        name_label = ctk.CTkLabel(
            self.gpu_frame,
            text="Device Name:",
            font=ctk.CTkFont(size=13, weight="bold")
        )
        name_label.grid(row=2, column=0, padx=15, pady=(10, 0), sticky="w")
        
        self.gpu_name = ctk.CTkLabel(
            self.gpu_frame,
            text="Unknown",
            font=ctk.CTkFont(size=13)
        )
        self.gpu_name.grid(row=2, column=1, padx=15, pady=(10, 0), sticky="w")
        
        # GPU type
        type_label = ctk.CTkLabel(
            self.gpu_frame,
            text="Device Type:",
            font=ctk.CTkFont(size=13, weight="bold")
        )
        type_label.grid(row=3, column=0, padx=15, pady=(10, 0), sticky="w")
        
        self.gpu_type = ctk.CTkLabel(
            self.gpu_frame,
            text="Unknown",
            font=ctk.CTkFont(size=13)
        )
        self.gpu_type.grid(row=3, column=1, padx=15, pady=(10, 0), sticky="w")
        
        # GPU memory
        memory_label = ctk.CTkLabel(
            self.gpu_frame,
            text="Memory:",
            font=ctk.CTkFont(size=13, weight="bold")
        )
        memory_label.grid(row=4, column=0, padx=15, pady=(10, 0), sticky="w")
        
        self.gpu_memory = ctk.CTkLabel(
            self.gpu_frame,
            text="Unknown",
            font=ctk.CTkFont(size=13)
        )
        self.gpu_memory.grid(row=4, column=1, padx=15, pady=(10, 0), sticky="w")
        
        # Driver version
        driver_label = ctk.CTkLabel(
            self.gpu_frame,
            text="Driver Version:",
            font=ctk.CTkFont(size=13, weight="bold")
        )
        driver_label.grid(row=5, column=0, padx=15, pady=(10, 0), sticky="w")
        
        self.driver_version = ctk.CTkLabel(
            self.gpu_frame,
            text="Unknown",
            font=ctk.CTkFont(size=13)
        )
        self.driver_version.grid(row=5, column=1, padx=15, pady=(10, 0), sticky="w")
        
        # Performance estimate
        perf_label = ctk.CTkLabel(
            self.gpu_frame,
            text="Performance:",
            font=ctk.CTkFont(size=13, weight="bold")
        )
        perf_label.grid(row=6, column=0, padx=15, pady=(10, 15), sticky="w")
        
        self.performance_estimate = ctk.CTkLabel(
            self.gpu_frame,
            text="Unknown",
            font=ctk.CTkFont(size=13)
        )
        self.performance_estimate.grid(row=6, column=1, padx=15, pady=(10, 15), sticky="w")
    
    def create_dependency_section(self) -> None:
        """Create dependency information and installation section with modern design."""
        # Dependency information frame
        self.dependency_frame = ctk.CTkFrame(self.content_frame, corner_radius=10)
        self.dependency_frame.grid(row=0, column=1, padx=15, pady=15, sticky="nsew")
        
        # Configure frame grid
        self.dependency_frame.grid_columnconfigure(0, weight=1)
        
        # Title
        dep_title = ctk.CTkLabel(
            self.dependency_frame,
            text="GPU Acceleration Dependencies",
            font=ctk.CTkFont(size=16, weight="bold")
        )
        dep_title.grid(row=0, column=0, padx=15, pady=(15, 10), sticky="w")
        
        # Create cards for each dependency
        self.create_dependency_card("CUDA Toolkit", "CUDA", 1)
        self.create_dependency_card("OpenCL Runtime", "OpenCL", 2)
        
        # Installation button
        self.install_button = ctk.CTkButton(
            self.dependency_frame,
            text="Install Missing Dependencies",
            state="disabled",
            command=self.install_dependencies,
            height=32,
            corner_radius=6
        )
        self.install_button.grid(row=3, column=0, padx=15, pady=(10, 0), sticky="ew")
        
        # Troubleshooting button
        self.troubleshoot_button = ctk.CTkButton(
            self.dependency_frame,
            text="Troubleshooting Guide",
            command=self.show_troubleshooting,
            height=32,
            corner_radius=6
        )
        self.troubleshoot_button.grid(row=4, column=0, padx=15, pady=(5, 10), sticky="ew")
        
        # Note
        note_text = """
Note: For optimal performance with NVIDIA GPUs, ensure the CUDA toolkit is properly installed.
For AMD GPUs, ensure OpenCL runtime is installed. If no GPU is available, the tool will
automatically fall back to CPU mode with significantly reduced performance.
        """
        
        note_label = ctk.CTkLabel(
            self.dependency_frame,
            text=note_text,
            font=ctk.CTkFont(size=12),
            justify="left",
            wraplength=400,
            text_color="#888888"
        )
        note_label.grid(row=5, column=0, padx=15, pady=(5, 15), sticky="w")
    
    def create_dependency_card(self, name: str, key: str, row: int) -> None:
        """Create a card-like display for a dependency."""
        card = ctk.CTkFrame(self.dependency_frame, fg_color=("#EEEEEE", "#333333"), corner_radius=6)
        card.grid(row=row, column=0, padx=15, pady=5, sticky="ew")
        
        # Card layout
        card.grid_columnconfigure(1, weight=1)
        
        # Dependency name
        name_label = ctk.CTkLabel(
            card,
            text=name,
            font=ctk.CTkFont(size=13, weight="bold")
        )
        name_label.grid(row=0, column=0, padx=(10, 5), pady=(10, 0), sticky="w")
        
        # Status label placeholder
        if key == "CUDA":
            self.cuda_status = ctk.CTkLabel(
                card,
                text="Checking...",
                font=ctk.CTkFont(size=12)
            )
            self.cuda_status.grid(row=0, column=1, padx=5, pady=(10, 0), sticky="e")
        else:
            self.opencl_status = ctk.CTkLabel(
                card,
                text="Checking...",
                font=ctk.CTkFont(size=12)
            )
            self.opencl_status.grid(row=0, column=1, padx=5, pady=(10, 0), sticky="e")
        
        # Version info or message
        if key == "CUDA":
            self.cuda_info = ctk.CTkLabel(
                card,
                text="Required for NVIDIA GPUs",
                font=ctk.CTkFont(size=12),
                text_color="#888888"
            )
            self.cuda_info.grid(row=1, column=0, columnspan=2, padx=10, pady=(0, 10), sticky="w")
        else:
            self.opencl_info = ctk.CTkLabel(
                card,
                text="Required for AMD GPUs",
                font=ctk.CTkFont(size=12),
                text_color="#888888"
            )
            self.opencl_info.grid(row=1, column=0, columnspan=2, padx=10, pady=(0, 10), sticky="w")
    
    def update_gpu_info(self, gpu_info: Dict[str, Any]) -> None:
        if not gpu_info:
            # No GPU detected
            self.gpu_status.configure(text="Not Available", text_color="#dc3545")
            self.gpu_name.configure(text="No GPU Detected")
            self.gpu_type.configure(text="CPU Mode")
            self.gpu_memory.configure(text="N/A")
            self.driver_version.configure(text="N/A")
            self.performance_estimate.configure(text="Reduced (CPU Only)", text_color="#FF6B35")
            
            # Update dependency status
            self.cuda_status.configure(text="Not Installed", text_color="#dc3545")
            self.opencl_status.configure(text="Not Installed", text_color="#dc3545")
            
            # Enable install button
            self.install_button.configure(state="normal")
            return
            
        # GPU detected - update information
        self.gpu_status.configure(text="Available", text_color="#22bb33")
        
        # Get GPU name
        name = gpu_info.get('name', 'Unknown GPU')
        self.gpu_name.configure(text=name)
        
        # Get backend type
        backend = gpu_info.get('backend', 'Unknown')
        self.gpu_type.configure(text=backend)
        
        # Get memory info if available
        if 'global_mem_size' in gpu_info:
            mem_mb = int(gpu_info['global_mem_size'] / (1024 * 1024))
            self.gpu_memory.configure(text=f"{mem_mb} MB")
        else:
            self.gpu_memory.configure(text="Unknown")
        
        # Get driver info
        if 'driver_version' in gpu_info:
            self.driver_version.configure(text=gpu_info['driver_version'])
        elif 'compute_capability' in gpu_info:
            self.driver_version.configure(text=f"CUDA {gpu_info['compute_capability']}")
        else:
            self.driver_version.configure(text="Unknown")
        
        # Set performance estimate
        self.performance_estimate.configure(text="Accelerated", text_color="#22bb33")
        
        # Update dependency status based on backend
        if backend == "CUDA":
            self.cuda_status.configure(text="Installed", text_color="#22bb33")
            self.cuda_info.configure(text=f"Version: {gpu_info.get('compute_capability', 'Unknown')}")
            self.opencl_status.configure(text="Not Required", text_color="#888888")
        elif backend == "OpenCL":
            self.opencl_status.configure(text="Installed", text_color="#22bb33")
            self.opencl_info.configure(text=f"Version: {gpu_info.get('version', 'Unknown')}")
            self.cuda_status.configure(text="Not Required", text_color="#888888")
        else:
            self.cuda_status.configure(text="Not Installed", text_color="#dc3545")
            self.opencl_status.configure(text="Not Installed", text_color="#dc3545")
            
        # Keep install button disabled if we have a GPU
        self.install_button.configure(state="disabled")
    
    def install_dependencies(self) -> None:
        # Create dialog window with installation instructions
        dialog = ctk.CTkToplevel(self)
        dialog.title("Install GPU Dependencies")
        dialog.geometry("500x400")
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()
        
        # Content frame
        content = ctk.CTkFrame(dialog)
        content.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Title
        title = ctk.CTkLabel(content, text="GPU Acceleration Dependencies", font=ctk.CTkFont(size=16, weight="bold"))
        title.pack(pady=(0, 15), anchor="w")
        
        # Instructions
        instructions = ctk.CTkLabel(
            content,
            text="Follow these steps to install the required dependencies for GPU acceleration:",
            font=ctk.CTkFont(size=12),
            justify="left",
            wraplength=450
        )
        instructions.pack(pady=(0, 10), anchor="w")
        
        # CUDA instructions
        cuda_label = ctk.CTkLabel(
            content,
            text="NVIDIA CUDA Toolkit:",
            font=ctk.CTkFont(size=13, weight="bold"),
            justify="left"
        )
        cuda_label.pack(pady=(10, 5), anchor="w")
        
        cuda_steps = ctk.CTkLabel(
            content,
            text="1. Download CUDA Toolkit from NVIDIA's website\n2. Follow installation instructions for your OS\n3. Restart your computer after installation\n4. Restart this application",
            justify="left",
            wraplength=450,
            font=ctk.CTkFont(size=12)
        )
        cuda_steps.pack(anchor="w")
        
        # OpenCL instructions
        opencl_label = ctk.CTkLabel(
            content,
            text="AMD/Intel OpenCL Runtime:",
            font=ctk.CTkFont(size=13, weight="bold"),
            justify="left"
        )
        opencl_label.pack(pady=(15, 5), anchor="w")
        
        opencl_steps = ctk.CTkLabel(
            content,
            text="1. Download drivers from AMD/Intel's website\n2. Install the latest graphics drivers for your GPU\n3. Restart your computer after installation\n4. Restart this application",
            justify="left",
            wraplength=450,
            font=ctk.CTkFont(size=12)
        )
        opencl_steps.pack(anchor="w")
        
        # Note at the bottom
        note = ctk.CTkLabel(
            content,
            text="Note: Without GPU acceleration, the application will still function using CPU processing, but at significantly reduced speeds.",
            wraplength=450,
            font=ctk.CTkFont(size=12),
            text_color="#888888",
            justify="left"
        )
        note.pack(pady=(20, 0), anchor="w")
        
        # Close button
        close_button = ctk.CTkButton(
            content,
            text="Close",
            command=dialog.destroy,
            width=100
        )
        close_button.pack(pady=(20, 0))
    
    def show_troubleshooting(self) -> None:
        # In a real implementation this would open a help document or website
        # For now, we'll just create a dialog with troubleshooting info
        dialog = ctk.CTkToplevel(self)
        dialog.title("GPU Troubleshooting Guide")
        dialog.geometry("500x400")
        dialog.transient(self.winfo_toplevel())
        dialog.grab_set()
        
        # Content frame
        content = ctk.CTkFrame(dialog)
        content.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Title
        title = ctk.CTkLabel(content, text="GPU Acceleration Troubleshooting", font=ctk.CTkFont(size=16, weight="bold"))
        title.pack(pady=(0, 15), anchor="w")
        
        # Instructions
        troubleshooting_text = """
Common Issues and Solutions:

1. GPU Not Detected
   • Ensure your GPU drivers are up to date
   • Verify that CUDA or OpenCL is properly installed
   • Try rebooting your system

2. "CUDA not available" Error
   • Install the latest NVIDIA drivers
   • Install the CUDA toolkit (minimum version 10.0)
   • Check if your GPU supports CUDA

3. "OpenCL not available" Error
   • Update graphics drivers from AMD/Intel
   • Ensure the OpenCL runtime is installed
   • Some older GPUs may not support OpenCL

4. Low Performance
   • Close other GPU-intensive applications
   • Monitor GPU temperature to check for throttling
   • Increase batch size in the settings tab
        """
        
        troubleshooting = ctk.CTkTextbox(content, height=250)
        troubleshooting.pack(fill="both", expand=True)
        troubleshooting.insert("1.0", troubleshooting_text)
        troubleshooting.configure(state="disabled")
        
        # Close button
        close_button = ctk.CTkButton(
            content,
            text="Close",
            command=dialog.destroy,
            width=100
        )
        close_button.pack(pady=(20, 0)) 