from setuptools import setup, find_packages
import os

# Read long description from README.md if it exists
readme_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "README.md")
long_description = ""
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as fh:
        long_description = fh.read()

# Read requirements from requirements.txt
requirements_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "requirements.txt")
with open(requirements_path, "r", encoding="utf-8") as f:
    requirements = f.read().splitlines()

setup(
    name="smore",
    version="1.0.0",
    packages=find_packages(),
    install_requires=requirements,
    author="Smore Team",
    author_email="example@example.com",
    description="Smore: A Bitcoin wallet brute-force tool for red team operations and cryptocurrency recovery scenarios",
    long_description=long_description,
    long_description_content_type="text/markdown",
    keywords="bitcoin, cryptocurrency, security, brute-force, red-team, smore",
    url="https://github.com/example/smore",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Information Technology",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Topic :: Security",
    ],
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "smore=smore.run_local:main",
        ],
    },
    package_data={
        "smore": ["assets/*", "requirements.txt"],
    },
    include_package_data=True,
) 