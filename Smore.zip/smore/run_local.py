#!/usr/bin/env python3
"""
Smore: Bitcoin Wallet Brute-force Tool
Main entry point for the application
"""
import os
import sys
import logging
import threading
from pathlib import Path

# Fix import paths
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, os.path.dirname(current_dir))

# Ensure logs directory exists
logs_dir = Path(current_dir) / "logs"
logs_dir.mkdir(exist_ok=True)

# Configure root logger
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(str(logs_dir / "smore.log")),
        logging.StreamHandler()
    ]
)

# Get logger
logger = logging.getLogger(__name__)

def main():
    """
    Main entry point for Smore: Bitcoin Wallet Brute-force Tool.
    Initializes and runs the GUI application.
    """
    try:
        # Import here to avoid circular imports
        from smore.gui.splash import show_splash_screen
        from smore.gui.app import BruteForceApp
        
        # Create splash screen
        root = show_splash_screen()
        
        # Create GUI application after splash screen
        app = BruteForceApp(root)
        
        # Run the application
        app.mainloop()
    except Exception as e:
        logger.error(f"Application error: {str(e)}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main() 